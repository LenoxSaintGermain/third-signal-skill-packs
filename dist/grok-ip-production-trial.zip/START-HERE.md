Read grok-ip-production-trial/PROMPT.md. Supply your selected private source package separately.
