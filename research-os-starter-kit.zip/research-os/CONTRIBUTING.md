# Contributing to Research OS

## Before You Write a Line of Code

1. Read `src/tokens.ts` — all visual constants live here
2. Read `src/types.ts` — all data interfaces live here
3. Read `src/lib/archivist.ts` — understand the Archivist's character before touching anything that interacts with it
4. Run `npm run dev` in seed mode (no env vars needed) to see what you're building on top of

## Code Standards

### TypeScript
- Strict mode is on — no `any`, no `@ts-ignore`
- All component props get explicit interfaces
- All async functions return `Promise<T>` explicitly

### Styling
- Inline `style` prop only — no CSS files, no Tailwind, no CSS modules
- Import from `@/tokens` — never hardcode hex values or font strings
- Transitions use `TRANSITIONS.fast/normal/slow` constants

### Components
- One component per file (exceptions: closely related pairs like `PaperCard` + `FeaturedPaper`)
- State lives in hooks — components are display-only when possible
- API calls go through `src/lib/api.ts` — never `fetch` directly from components

### The Archivist
- Never call `callArchivist` directly from a component — always go through `useArchivist`
- If you change the system prompt in `archivist.ts`, test the character. Does it still speak in 2-4 sentences? Does it still lead with an observation, not a question?
- The suggested questions in `SUGGESTED_QUESTIONS` are part of the UX — review with the product owner before changing them

## Branch Naming
```
feature/paper-detail-view
fix/archivist-scroll-bug
chore/add-signal-graph-types
```

## Commit Convention
```
feat: add paper detail view with section rendering
fix: archivist panel height on mobile
chore: add ENTERPRISE_TRANSFORMATION seed paper
```

## What Needs Review Before Merge
- Any change to `src/lib/archivist.ts` (system prompt, character, proactive prompts)
- Any new paper added to `src/data/seed.ts` (quality bar for signals and sections)
- Any change to `src/tokens.ts` (design system consistency)
- Any new route added to `App.tsx`

## Don't Do These Things
- Don't hardcode paper IDs as strings — use `paper.id` from the data
- Don't skip seed mode fallbacks in `src/lib/api.ts` — every API method needs one
- Don't add loading state to components — put it in the hook
- Don't touch the Archivist character without reading it first
