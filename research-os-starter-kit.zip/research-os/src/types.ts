// ── Research OS Frontend Types ────────────────────────────────────────────

export type ClusterType =
  | 'AI_SYSTEMS'
  | 'PROFESSIONAL_IDENTITY'
  | 'GOVERNANCE'
  | 'HUMAN_AI_COLLABORATION'
  | 'ENTERPRISE_TRANSFORMATION'

export type DepthType = 'SURFACE' | 'DEEP' | 'FULL_IMMERSION'

export type SectionType =
  | 'THESIS'
  | 'ARGUMENT'
  | 'EVIDENCE'
  | 'DIAGRAM'
  | 'TENSION'
  | 'SIGNAL'
  | 'FIELD_NOTE'
  | 'IMPLICATION'
  | 'CITATION'

export type RelationType =
  | 'SUPPORTS'
  | 'TENSIONS_WITH'
  | 'EXTENDS'
  | 'CONTRADICTS'

export type PipelineStatus =
  | 'queued'
  | 'ingesting'
  | 'parsing'
  | 'enriching'
  | 'awaiting_review'
  | 'published'
  | 'failed'

// ── Paper ─────────────────────────────────────────────────────────────────

export interface PaperSection {
  id: string
  type: SectionType
  content: string
  order: number
  anchorId: string
  diagramRef?: string
}

export interface Signal {
  id: string
  paperId: string
  content: string
  weight: number
  cluster: ClusterType
  tags: string[]
  approved: boolean
}

export interface Tension {
  id: string
  fromSignalId: string
  toSignalId: string
  fromPaperId: string
  toPaperId: string
  relationType: RelationType
  description: string
  authored: boolean
}

export interface Citation {
  id: string
  paperId: string
  text: string
  source?: string
  year?: number
  doi?: string
}

export interface Paper {
  id: string
  issue: string
  title: string
  subtitle: string
  abstract: string
  cluster: ClusterType
  depth: DepthType
  readTime: string
  date: string
  tags: string[]
  signals: Signal[]
  sections: PaperSection[]
  citations: Citation[]
  tensions: Tension[]
  featured?: boolean
  accentColor?: string
  status: PipelineStatus
}

// ── Signal Graph ──────────────────────────────────────────────────────────

export interface SignalNode {
  id: string
  paperId: string
  paperTitle: string
  content: string
  weight: number
  cluster: ClusterType
  tags: string[]
}

export interface SignalEdge {
  id: string
  fromSignalId: string
  toSignalId: string
  relationType: RelationType
  confidence: number
  authored: boolean
}

// ── Ingest ────────────────────────────────────────────────────────────────

export type IngestSourceType =
  | 'gdoc'
  | 'pdf'
  | 'markdown'
  | 'raw_text'
  | 'orbital_conversation'
  | 'orbital_agent_output'

export interface IngestRequest {
  title?: string
  content: string
  sourceType: IngestSourceType
  sourceUrl?: string
  cluster?: ClusterType
  tags?: string[]
  enrichmentOptions?: {
    autoDetectSections: boolean
    extractSignals: boolean
    crossReferenceLibrary: boolean
    flagDiagramCandidates: boolean
    detectTensions: boolean
  }
}

export interface IngestResponse {
  draftId: string
  status: PipelineStatus
  detectedTitle?: string
  detectedCluster?: ClusterType
  signalCandidates?: string[]
  diagramCandidates?: number
  tensionsDetected?: number
  reviewRequired: boolean
  reviewUrl?: string
  message: string
}

// ── Archivist ─────────────────────────────────────────────────────────────

export interface ArchivistMessage {
  role: 'user' | 'assistant'
  content: string
  timestamp?: string
}

export interface ArchivistState {
  open: boolean
  loading: boolean
  messages: ArchivistMessage[]
  hoveredPaper: Paper | null
  initiated: boolean
}

// ── UI State ──────────────────────────────────────────────────────────────

export interface LibraryFilters {
  cluster: ClusterType | 'ALL'
  depth: DepthType | 'ALL'
  sort: 'chronological' | 'depth' | 'signals'
}

export interface LibraryState {
  papers: Paper[]
  loading: boolean
  error: string | null
  filters: LibraryFilters
  hoveredPaper: Paper | null
  showIngest: boolean
}
