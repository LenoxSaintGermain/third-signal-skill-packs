// ── Research OS Design Tokens ─────────────────────────────────────────────
// Single source of truth for all visual constants.
// Import from here — never hardcode color/font/spacing values in components.

export const COLORS = {
  // Backgrounds
  bg:       '#0C0E0D',
  bgMid:    '#111412',
  bgSurf:   '#161918',
  bgCard:   '#1A1D1B',

  // Accents
  teal:     '#4B9E8D',
  tealDim:  '#2D6B5F',
  tealBg:   'rgba(75,158,141,0.08)',
  tealBorder:'rgba(75,158,141,0.3)',

  brown:    '#8C6A4A',
  brownLight:'#B8956A',
  brownBg:  'rgba(140,106,74,0.1)',

  amber:    '#C9853A',
  amberBg:  'rgba(201,133,58,0.1)',

  risk:     '#B84E3A',

  // Borders
  border:   '#232926',
  borderMid:'#2E3330',

  // Text
  muted:    '#6B7570',
  mutedMid: '#8A9490',
  light:    '#C8CEC9',
  cream:    '#E8E4DA',
} as const

export const FONTS = {
  serif:  "'Playfair Display', Georgia, serif",
  body:   "'EB Garamond', 'Times New Roman', serif",
  mono:   "'IBM Plex Mono', 'Courier New', monospace",
} as const

export const FONT_SIZES = {
  label:  9,
  small:  11,
  body:   15,
  bodyLg: 16,
  h4:     18,
  h3:     22,
  h2:     28,
  h1:     42,
} as const

export const SPACING = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
  xxxl: 64,
} as const

export const TRANSITIONS = {
  fast:   'all 0.15s ease',
  normal: 'all 0.22s ease',
  slow:   'all 0.4s cubic-bezier(0.16,1,0.3,1)',
} as const

// CSS string for Google Fonts import — already in index.html
export const GLOBAL_CSS = `
  * { box-sizing: border-box; margin: 0; padding: 0; }

  body {
    background: ${COLORS.bg};
    color: ${COLORS.light};
    font-family: ${FONTS.body};
  }

  ::-webkit-scrollbar { width: 4px; height: 4px; }
  ::-webkit-scrollbar-track { background: transparent; }
  ::-webkit-scrollbar-thumb { background: ${COLORS.borderMid}; }

  @keyframes breathe {
    0%, 100% { opacity: 0.5; transform: scale(1); }
    50%       { opacity: 1;   transform: scale(1.35); }
  }

  @keyframes pulse {
    0%, 100% { opacity: 0.25; }
    50%       { opacity: 1; }
  }

  @keyframes fadeInUp {
    from { opacity: 0; transform: translateY(8px); }
    to   { opacity: 1; transform: translateY(0); }
  }

  @keyframes scanLine {
    from { transform: translateY(-100%); opacity: 0.6; }
    to   { transform: translateY(100%);  opacity: 0; }
  }

  @keyframes shimmer {
    0%   { background-position: -400px 0; }
    100% { background-position:  400px 0; }
  }
`
