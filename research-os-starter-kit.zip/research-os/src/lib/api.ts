// ── Research OS API Client ────────────────────────────────────────────────
// Uses the real Research OS REST API when VITE_RESEARCH_OS_BASE_URL is set.
// Falls back to seed data automatically in development / demo mode.

import { Paper, Signal, IngestRequest, IngestResponse, ClusterType, DepthType } from '@/types'
import { SEED_PAPERS } from '@/data/seed'

const BASE_URL = import.meta.env.VITE_RESEARCH_OS_BASE_URL as string | undefined
const API_KEY  = import.meta.env.VITE_RESEARCH_OS_API_KEY  as string | undefined

const SEED_MODE = !BASE_URL

// ── HTTP helpers ──────────────────────────────────────────────────────────

async function apiRequest<T>(
  method: string,
  path: string,
  body?: unknown,
  params?: Record<string, string | number | boolean | undefined>,
): Promise<T> {
  if (SEED_MODE) throw new Error('API not configured — running in seed mode')

  const url = new URL(`${BASE_URL}${path}`)
  if (params) {
    Object.entries(params).forEach(([k, v]) => {
      if (v !== undefined) url.searchParams.set(k, String(v))
    })
  }

  const res = await fetch(url.toString(), {
    method,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${API_KEY}`,
      'X-Client': 'research-os-ui/0.1',
    },
    body: body ? JSON.stringify(body) : undefined,
  })

  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }))
    throw new Error(`[${res.status}] ${err.error ?? res.statusText}`)
  }

  const data = await res.json()
  return data.data as T
}

// ── Paper API ─────────────────────────────────────────────────────────────

export async function listPapers(filters?: {
  cluster?: ClusterType | 'ALL'
  depth?: DepthType | 'ALL'
  tags?: string[]
  limit?: number
  offset?: number
}): Promise<{ papers: Paper[]; total: number; hasMore: boolean }> {
  if (SEED_MODE) {
    let papers = [...SEED_PAPERS]
    if (filters?.cluster && filters.cluster !== 'ALL') {
      papers = papers.filter(p => p.cluster === filters.cluster)
    }
    if (filters?.depth && filters.depth !== 'ALL') {
      papers = papers.filter(p => p.depth === filters.depth)
    }
    return { papers, total: papers.length, hasMore: false }
  }

  return apiRequest('GET', '/papers', undefined, {
    cluster: filters?.cluster !== 'ALL' ? filters?.cluster : undefined,
    depth: filters?.depth !== 'ALL' ? filters?.depth : undefined,
    limit: filters?.limit ?? 20,
    offset: filters?.offset ?? 0,
  })
}

export async function getPaper(paperId: string): Promise<Paper> {
  if (SEED_MODE) {
    const paper = SEED_PAPERS.find(p => p.id === paperId)
    if (!paper) throw new Error(`Paper not found: ${paperId}`)
    return paper
  }
  return apiRequest('GET', `/papers/${paperId}`)
}

export async function searchPapers(
  query: string,
  options?: { cluster?: ClusterType; limit?: number; semantic?: boolean },
): Promise<{ papers: Paper[]; total: number }> {
  if (SEED_MODE) {
    const q = query.toLowerCase()
    const papers = SEED_PAPERS.filter(
      p =>
        p.title.toLowerCase().includes(q) ||
        p.abstract.toLowerCase().includes(q) ||
        p.tags.some(t => t.toLowerCase().includes(q)) ||
        p.signals.some(s => s.content.toLowerCase().includes(q)),
    )
    return { papers, total: papers.length }
  }
  return apiRequest('GET', '/papers/search', undefined, { q: query, ...options })
}

// ── Signal API ────────────────────────────────────────────────────────────

export async function getSignals(filters?: {
  paperId?: string
  cluster?: ClusterType
  minWeight?: number
  limit?: number
}): Promise<Signal[]> {
  if (SEED_MODE) {
    let signals = SEED_PAPERS.flatMap(p => p.signals)
    if (filters?.paperId) signals = signals.filter(s => s.paperId === filters.paperId)
    if (filters?.cluster) signals = signals.filter(s => s.cluster === filters.cluster)
    if (filters?.minWeight) signals = signals.filter(s => s.weight >= (filters.minWeight ?? 0))
    return signals.slice(0, filters?.limit ?? 50)
  }
  return apiRequest('GET', '/signals', undefined, filters as Record<string, string | number | boolean | undefined>)
}

// ── Ingest API ────────────────────────────────────────────────────────────

export async function ingestArtifact(request: IngestRequest): Promise<IngestResponse> {
  if (SEED_MODE) {
    // Simulate pipeline in seed mode
    await new Promise(r => setTimeout(r, 800))
    return {
      draftId: `draft-${Date.now()}`,
      status: 'awaiting_review',
      detectedTitle: request.title ?? 'Untitled Draft',
      detectedCluster: 'AI_SYSTEMS',
      signalCandidates: ['Candidate signal 1', 'Candidate signal 2'],
      diagramCandidates: 1,
      tensionsDetected: 0,
      reviewRequired: true,
      message: '[SEED MODE] Draft queued for review. In production, this triggers the full 8-stage pipeline.',
    }
  }
  return apiRequest('POST', '/ingest', request)
}

export async function getIngestStatus(draftId: string): Promise<{
  draftId: string
  status: string
  progress: number
  currentStage: string
}> {
  if (SEED_MODE) {
    return { draftId, status: 'awaiting_review', progress: 100, currentStage: 'Awaiting author review' }
  }
  return apiRequest('GET', `/ingest/${draftId}/status`)
}

// ── Mode Helpers ──────────────────────────────────────────────────────────

export const isSeedMode = (): boolean => SEED_MODE

export const getModeLabel = (): string =>
  SEED_MODE ? 'SEED MODE — set VITE_RESEARCH_OS_BASE_URL to connect live API' : 'LIVE'
