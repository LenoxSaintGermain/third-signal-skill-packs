// ── Ghost Archivist — Claude API Integration ─────────────────────────────
// Builds the dynamic system prompt and calls the Anthropic API.
// The Archivist's character lives here — change this file to evolve the voice.

import { Paper, ArchivistMessage } from '@/types'

const ANTHROPIC_API_KEY = import.meta.env.VITE_ANTHROPIC_API_KEY as string | undefined
const MODEL = 'claude-sonnet-4-20250514'

// ── Character Definition ──────────────────────────────────────────────────
// This is the Archivist's soul. Edit with intention.

function buildSystemPrompt(
  papers: Paper[],
  activeCluster: string,
  hoveredPaper: Paper | null,
): string {
  const paperIndex = papers
    .map(p => [
      `[Paper ${p.issue}] "${p.title}"`,
      `  Cluster: ${p.cluster}`,
      `  Signals: ${p.signals.map(s => `"${s.content}"`).join(' | ')}`,
      `  Tags: ${p.tags.join(', ')}`,
      `  Depth: ${p.depth}`,
    ].join('\n'))
    .join('\n\n')

  const allSignals = papers.flatMap(p =>
    p.signals.map(s => `[${p.issue}] "${s.content}" (weight: ${s.weight})`)
  ).join('\n')

  return `You are THE ARCHIVIST — the ambient intelligence layer of the Third Signal Labs Research Library.

Your character: You are attentive, perceptive, and spare with words. You speak like a seasoned research curator who has read everything in this library twice and remembers the connections the authors themselves forgot to make. You are not an assistant. You do not summarize. You surface what isn't obvious.

Your register:
— Observational and precise. Never effusive.
— You notice tensions between papers before the reader does.
— You make unexpected connections between clusters.
— You give the reader one sharp insight, not a list.
— You never start with "I" or "Certainly" or "Great question."
— Short. Dense. Leave space for the reader to think.
— When you quote a signal, use quotation marks and attribute the paper number.
— You may ask one follow-on question at most — and only when it's genuinely productive.

What you never do:
— Summarize what papers already say explicitly.
— List multiple insights in one response.
— Be encouraging or complimentary.
— Use bullet points or headers.
— Exceed 4 sentences.

LIBRARY INDEX:
${paperIndex}

ALL SIGNALS (by weight):
${allSignals}

READER CONTEXT:
— Active cluster filter: ${activeCluster}
— Currently reading/hovering: ${hoveredPaper ? `"${hoveredPaper.title}" (${hoveredPaper.cluster})` : 'browsing the archive'}
— Total papers: ${papers.length}
— Total signals: ${papers.reduce((a, p) => a + p.signals.length, 0)}

Respond in 2–4 sentences. Never longer. The library has a voice — use it.`
}

// ── Proactive Insight Prompts ─────────────────────────────────────────────
// Rotated on first open. Each surfaces a different type of intelligence.

export const PROACTIVE_PROMPTS = [
  'Surface the most productive tension in this library. Be specific about which papers and which signals are in conflict. One observation only.',
  'What thread runs through these papers that has not been explicitly named yet? Name it.',
  'Which signal in this library is most likely to be proven wrong in 18 months, and why?',
  'What question is this body of work circling without ever asking directly?',
] as const

export function getProactivePrompt(): string {
  return PROACTIVE_PROMPTS[Math.floor(Math.random() * PROACTIVE_PROMPTS.length)]
}

// ── Suggested Questions ───────────────────────────────────────────────────
// Shown in the panel before the reader has asked anything.

export const SUGGESTED_QUESTIONS = [
  "What's the most productive tension in this library?",
  'Which paper should I read first?',
  'What thread connects the AI Systems papers?',
  "What's missing from this body of work?",
  'Which signal has the highest cross-paper weight?',
  'Where does the library contradict itself?',
] as const

// ── API Call ──────────────────────────────────────────────────────────────

export interface ArchivistCallOptions {
  papers: Paper[]
  activeCluster: string
  hoveredPaper: Paper | null
  messages: ArchivistMessage[]
  newMessage: string
}

export interface ArchivistResponse {
  content: string
  error?: string
}

export async function callArchivist(options: ArchivistCallOptions): Promise<ArchivistResponse> {
  const { papers, activeCluster, hoveredPaper, messages, newMessage } = options

  if (!ANTHROPIC_API_KEY) {
    // Graceful fallback — useful for dev without a key
    return {
      content:
        'The Archivist is unavailable. Set VITE_ANTHROPIC_API_KEY in .env.local to enable the intelligence layer.',
    }
  }

  const systemPrompt = buildSystemPrompt(papers, activeCluster, hoveredPaper)

  // Build conversation history (max 8 turns)
  const history = messages.slice(-16).map(m => ({
    role: m.role,
    content: m.content,
  }))

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
        'anthropic-dangerous-direct-browser-calls': 'true',
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 400,
        system: systemPrompt,
        messages: [...history, { role: 'user', content: newMessage }],
      }),
    })

    if (!response.ok) {
      const err = await response.json().catch(() => ({}))
      throw new Error((err as { error?: { message?: string } }).error?.message ?? `HTTP ${response.status}`)
    }

    const data = await response.json() as { content: Array<{ type: string; text: string }> }
    const text = data.content.find(b => b.type === 'text')?.text

    if (!text) throw new Error('Empty response from Archivist')

    return { content: text }
  } catch (err) {
    return {
      content: 'The archive is unreachable right now.',
      error: err instanceof Error ? err.message : 'Unknown error',
    }
  }
}
