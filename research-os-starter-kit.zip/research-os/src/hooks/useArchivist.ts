// ── useArchivist Hook ─────────────────────────────────────────────────────
// Manages the full Ghost Archivist state: open/close, messages, loading,
// hover context, proactive insight on first open.

import { useState, useCallback, useRef } from 'react'
import { Paper, ArchivistMessage } from '@/types'
import { callArchivist, getProactivePrompt } from '@/lib/archivist'

export interface UseArchivistOptions {
  papers: Paper[]
  activeCluster: string
}

export function useArchivist({ papers, activeCluster }: UseArchivistOptions) {
  const [open, setOpen] = useState(false)
  const [loading, setLoading] = useState(false)
  const [messages, setMessages] = useState<ArchivistMessage[]>([])
  const [hoveredPaper, setHoveredPaper] = useState<Paper | null>(null)
  const initiated = useRef(false)

  const addMessage = useCallback((msg: ArchivistMessage) => {
    setMessages(prev => [...prev, msg])
  }, [])

  const sendMessage = useCallback(
    async (userContent: string, isSystem = false) => {
      if (!isSystem) {
        addMessage({ role: 'user', content: userContent })
      }
      setLoading(true)

      const response = await callArchivist({
        papers,
        activeCluster,
        hoveredPaper,
        messages,
        newMessage: userContent,
      })

      addMessage({ role: 'assistant', content: response.content })
      setLoading(false)
    },
    [papers, activeCluster, hoveredPaper, messages, addMessage],
  )

  const openPanel = useCallback(async () => {
    setOpen(true)
    if (initiated.current) return
    initiated.current = true
    // Fire proactive insight on first open
    await sendMessage(getProactivePrompt(), true)
  }, [sendMessage])

  const closePanel = useCallback(() => {
    setOpen(false)
  }, [])

  const toggle = useCallback(async () => {
    if (open) closePanel()
    else await openPanel()
  }, [open, openPanel, closePanel])

  return {
    open,
    loading,
    messages,
    hoveredPaper,
    setHoveredPaper,
    sendMessage,
    openPanel,
    closePanel,
    toggle,
  }
}
