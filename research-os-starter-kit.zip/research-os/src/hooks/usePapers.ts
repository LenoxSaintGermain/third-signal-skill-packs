// ── usePapers Hook ────────────────────────────────────────────────────────

import { useState, useEffect, useCallback } from 'react'
import { Paper, LibraryFilters } from '@/types'
import { listPapers } from '@/lib/api'

const DEFAULT_FILTERS: LibraryFilters = {
  cluster: 'ALL',
  depth: 'ALL',
  sort: 'chronological',
}

export function usePapers() {
  const [papers, setPapers] = useState<Paper[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [filters, setFilters] = useState<LibraryFilters>(DEFAULT_FILTERS)

  const load = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const result = await listPapers({
        cluster: filters.cluster,
        depth: filters.depth,
      })
      setPapers(result.papers)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load papers')
    } finally {
      setLoading(false)
    }
  }, [filters.cluster, filters.depth])

  useEffect(() => {
    void load()
  }, [load])

  const setCluster = useCallback((cluster: LibraryFilters['cluster']) => {
    setFilters(f => ({ ...f, cluster }))
  }, [])

  const setDepth = useCallback((depth: LibraryFilters['depth']) => {
    setFilters(f => ({ ...f, depth }))
  }, [])

  const setSort = useCallback((sort: LibraryFilters['sort']) => {
    setFilters(f => ({ ...f, sort }))
  }, [])

  const featured = papers.find(p => p.featured)
  const grid = papers.filter(p => !p.featured || filters.cluster !== 'ALL')

  return {
    papers,
    featured,
    grid,
    loading,
    error,
    filters,
    setCluster,
    setDepth,
    setSort,
    reload: load,
  }
}
