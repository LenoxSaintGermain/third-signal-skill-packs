// ── App.tsx ───────────────────────────────────────────────────────────────

import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { GLOBAL_CSS } from '@/tokens'
import { LibraryView } from '@/components/library/LibraryView'
import { PaperView } from '@/components/paper/PaperView'
import { SignalGraphView } from '@/components/graph/SignalGraphView'

// Inject global styles once
const styleEl = document.createElement('style')
styleEl.textContent = GLOBAL_CSS
document.head.appendChild(styleEl)

export function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/"            element={<LibraryView />} />
        <Route path="/paper/:id"   element={<PaperView />} />
        <Route path="/signals"     element={<SignalGraphView />} />
        <Route path="*"            element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  )
}
