// ── Seed Papers ───────────────────────────────────────────────────────────
// Used when VITE_RESEARCH_OS_BASE_URL is not set (development / demo mode).
// Replace with real API data in production.

import { Paper } from '@/types'
import { COLORS } from '@/tokens'

export const SEED_PAPERS: Paper[] = [
  {
    id: 'mneme-001',
    issue: '001',
    title: 'MNEME: Multimodal Neuro-Emotional Memory Engine',
    subtitle: 'A federated emotional memory protocol for persistent human-AI relationships',
    abstract:
      'Current AI memory architectures treat recall as retrieval. MNEME proposes a fundamentally different primitive — the Emotional Anchor Object (EAO) — that encodes not just what was said, but the emotional register, relational weight, and contextual salience of every interaction. This paper defines the EAO schema, federation architecture, and market validation path.',
    cluster: 'AI_SYSTEMS',
    depth: 'FULL_IMMERSION',
    readTime: '24 min',
    date: 'FEB 2026',
    tags: ['MEMORY', 'EAO', 'FEDERATION', 'EMOTIONAL AI'],
    featured: true,
    accentColor: COLORS.teal,
    status: 'published',
    signals: [
      {
        id: 'sig-mneme-001',
        paperId: 'mneme-001',
        content: 'Memory without emotional weight is retrieval, not relationship.',
        weight: 4,
        cluster: 'AI_SYSTEMS',
        tags: ['MEMORY', 'EMOTIONAL AI'],
        approved: true,
      },
      {
        id: 'sig-mneme-002',
        paperId: 'mneme-001',
        content: 'The EAO primitive solves the cold-start problem for long-term AI companions.',
        weight: 3,
        cluster: 'AI_SYSTEMS',
        tags: ['EAO', 'MEMORY'],
        approved: true,
      },
      {
        id: 'sig-mneme-003',
        paperId: 'mneme-001',
        content: 'Federation is not optional — sovereign memory requires distributed trust.',
        weight: 2,
        cluster: 'AI_SYSTEMS',
        tags: ['FEDERATION'],
        approved: true,
      },
      {
        id: 'sig-mneme-004',
        paperId: 'mneme-001',
        content: "ElevenLabs' Series D validates the emotional AI memory market at scale.",
        weight: 2,
        cluster: 'AI_SYSTEMS',
        tags: ['MARKET', 'EMOTIONAL AI'],
        approved: true,
      },
    ],
    sections: [
      {
        id: 'sec-mneme-01',
        type: 'THESIS',
        content:
          'AI memory systems that treat emotional context as metadata rather than first-class data will systematically fail to build genuine long-term relationships — and the Emotional Anchor Object (EAO) is the architectural primitive that corrects this.',
        order: 1,
        anchorId: 'thesis',
      },
      {
        id: 'sec-mneme-02',
        type: 'ARGUMENT',
        content:
          'Current memory architectures — vector stores, conversation summaries, episodic buffers — are retrieval systems. They can surface what was said. They cannot encode why it mattered. The difference between a system that remembers "user mentioned their daughter" and a system that encodes that this mention carried high emotional salience, occurred during a moment of expressed anxiety, and should inform tone for the next 6 interactions — that difference is the entire product.',
        order: 2,
        anchorId: 'argument-retrieval',
      },
      {
        id: 'sec-mneme-03',
        type: 'SIGNAL',
        content: 'Memory without emotional weight is retrieval, not relationship.',
        order: 3,
        anchorId: 'signal-01',
      },
      {
        id: 'sec-mneme-04',
        type: 'EVIDENCE',
        content:
          "ElevenLabs raised a $180M Series D in January 2026, with emotional voice AI as the core differentiator. The market is pricing emotional intelligence as the next competitive layer. MNEME's architecture positions Third Signal at the memory layer beneath that market.",
        order: 4,
        anchorId: 'evidence-market',
      },
      {
        id: 'sec-mneme-05',
        type: 'DIAGRAM',
        content:
          'EAO Schema: { id, sessionId, timestamp, emotionalRegister: [valence, arousal, dominance], relationalWeight: float, content: string, contextTags: string[], decayProfile: DecayFunction }',
        order: 5,
        anchorId: 'diagram-eao',
        diagramRef: 'eao-schema',
      },
      {
        id: 'sec-mneme-06',
        type: 'TENSION',
        content:
          'The strongest objection: emotional context is too subjective to formalize. A schema that encodes emotional register will encode the biases of its training data, not the actual emotional state of the user. Counter: the EAO does not claim to read emotions — it encodes the system\'s probabilistic model of emotional context, which is the only data an AI has access to. The schema makes this explicit rather than hiding it.',
        order: 6,
        anchorId: 'tension-subjectivity',
      },
      {
        id: 'sec-mneme-07',
        type: 'IMPLICATION',
        content:
          "If MNEME's federation protocol is adopted as infrastructure, it becomes a trust layer for all persistent AI relationships — not just Third Signal's products. The protocol IP is more valuable than any single product built on it.",
        order: 7,
        anchorId: 'implication-protocol',
      },
    ],
    citations: [
      {
        id: 'cite-mneme-01',
        paperId: 'mneme-001',
        text: "ElevenLabs Series D Announcement",
        source: 'TechCrunch',
        year: 2026,
      },
    ],
    tensions: [],
  },
  {
    id: 'professional-dna-002',
    issue: '002',
    title: 'Professional DNA: The Case for Career Intelligence as Infrastructure',
    subtitle: 'Why the next competitive layer is knowing what the labor market knows before it acts',
    abstract:
      'Career navigation tools are built on self-report and keyword matching. Professional DNA argues that the real signal lives in the gap between how a professional describes themselves and how the labor market has already priced them — and that closing that gap requires treating career intelligence as infrastructure, not as a feature.',
    cluster: 'PROFESSIONAL_IDENTITY',
    depth: 'DEEP',
    readTime: '18 min',
    date: 'JAN 2026',
    tags: ['CAREER', 'INTELLIGENCE', 'LABOR MARKET', 'SIGNAL'],
    featured: false,
    accentColor: COLORS.brown,
    status: 'published',
    signals: [
      {
        id: 'sig-dna-001',
        paperId: 'professional-dna-002',
        content: 'The resume is a lossy compression of professional identity.',
        weight: 5,
        cluster: 'PROFESSIONAL_IDENTITY',
        tags: ['CAREER', 'SIGNAL'],
        approved: true,
      },
      {
        id: 'sig-dna-002',
        paperId: 'professional-dna-002',
        content: 'Market-calibrated intelligence requires live data, not periodic snapshots.',
        weight: 3,
        cluster: 'PROFESSIONAL_IDENTITY',
        tags: ['LABOR MARKET', 'INTELLIGENCE'],
        approved: true,
      },
      {
        id: 'sig-dna-003',
        paperId: 'professional-dna-002',
        content:
          'Suppressor signals — what the market penalizes that the professional cannot see — are the highest-value insight.',
        weight: 4,
        cluster: 'PROFESSIONAL_IDENTITY',
        tags: ['SIGNAL', 'MARKET'],
        approved: true,
      },
    ],
    sections: [
      {
        id: 'sec-dna-01',
        type: 'THESIS',
        content:
          'Career intelligence tools that rely on self-report and keyword matching will always lag the market by months — and the professionals who lose the most are the ones who have the highest gap between how they describe themselves and how the market has priced them.',
        order: 1,
        anchorId: 'thesis',
      },
    ],
    citations: [],
    tensions: [
      {
        id: 'ten-001',
        fromSignalId: 'sig-mneme-001',
        toSignalId: 'sig-dna-001',
        fromPaperId: 'mneme-001',
        toPaperId: 'professional-dna-002',
        relationType: 'EXTENDS',
        description:
          'Both papers argue that current systems compress the wrong signal. MNEME compresses emotional context; Professional DNA compresses market perception. The underlying pattern — lossy compression producing blind spots — is the same.',
        authored: true,
      },
    ],
  },
  {
    id: 'ghost-hand-003',
    issue: '003',
    title: 'Ghost Hand: Agentic Systems That Operate Without Being Seen',
    subtitle: 'Design principles for AI agents that augment human judgment invisibly',
    abstract:
      'The most powerful AI systems are the ones that never announce themselves. Ghost Hand proposes a framework for designing agentic AI that operates at the layer below conscious attention — handling the mechanical, amplifying the strategic, and disappearing before the user notices it was there.',
    cluster: 'AI_SYSTEMS',
    depth: 'DEEP',
    readTime: '15 min',
    date: 'DEC 2025',
    tags: ['AGENTS', 'AUTONOMY', 'DESIGN PRINCIPLES'],
    featured: false,
    accentColor: COLORS.amber,
    status: 'published',
    signals: [
      {
        id: 'sig-ghost-001',
        paperId: 'ghost-hand-003',
        content: 'The best AI agent is the one you forget is running.',
        weight: 6,
        cluster: 'AI_SYSTEMS',
        tags: ['AGENTS', 'DESIGN'],
        approved: true,
      },
      {
        id: 'sig-ghost-002',
        paperId: 'ghost-hand-003',
        content:
          'Agentic invisibility requires explicit legibility — the agent must be perfectly auditable even when silent.',
        weight: 4,
        cluster: 'AI_SYSTEMS',
        tags: ['AGENTS', 'GOVERNANCE'],
        approved: true,
      },
      {
        id: 'sig-ghost-003',
        paperId: 'ghost-hand-003',
        content:
          'Human judgment is the ceiling. AI execution is the floor. The gap between them is the product.',
        weight: 5,
        cluster: 'AI_SYSTEMS',
        tags: ['AGENTS', 'AUTONOMY'],
        approved: true,
      },
    ],
    sections: [
      {
        id: 'sec-ghost-01',
        type: 'THESIS',
        content:
          'The dominant design failure in agentic AI is announcement — systems that narrate their own execution produce user anxiety, distrust, and over-reliance. The design goal should be invisibility with perfect auditability on demand.',
        order: 1,
        anchorId: 'thesis',
      },
    ],
    citations: [],
    tensions: [],
  },
  {
    id: 'coe-cookie-004',
    issue: '004',
    title: 'COE Cookie: Enterprise AI Governance Through Behavioral Telemetry',
    subtitle: 'A lightweight protocol for observing AI adoption patterns without surveillance',
    abstract:
      'Enterprise AI Centers of Excellence are flying blind. Adoption metrics tell you what tools were opened, not what intelligence was created. COE Cookie proposes a behavioral telemetry layer that captures the moments of AI value creation without becoming a surveillance infrastructure.',
    cluster: 'GOVERNANCE',
    depth: 'SURFACE',
    readTime: '11 min',
    date: 'NOV 2025',
    tags: ['GOVERNANCE', 'ENTERPRISE', 'TELEMETRY', 'COE'],
    featured: false,
    accentColor: COLORS.mutedMid,
    status: 'published',
    signals: [
      {
        id: 'sig-coe-001',
        paperId: 'coe-cookie-004',
        content:
          'You cannot govern what you cannot observe. But observation must not become surveillance.',
        weight: 5,
        cluster: 'GOVERNANCE',
        tags: ['GOVERNANCE', 'ETHICS'],
        approved: true,
      },
      {
        id: 'sig-coe-002',
        paperId: 'coe-cookie-004',
        content:
          'AI adoption metrics are vanity metrics until they capture decision acceleration.',
        weight: 3,
        cluster: 'GOVERNANCE',
        tags: ['ENTERPRISE', 'TELEMETRY'],
        approved: true,
      },
      {
        id: 'sig-coe-003',
        paperId: 'coe-cookie-004',
        content:
          "The CoE's job is not to train users — it is to make the organization legible to itself.",
        weight: 4,
        cluster: 'GOVERNANCE',
        tags: ['COE', 'ENTERPRISE'],
        approved: true,
      },
    ],
    sections: [],
    citations: [],
    tensions: [],
  },
]

export const SEED_CLUSTERS = [
  'AI_SYSTEMS',
  'PROFESSIONAL_IDENTITY',
  'GOVERNANCE',
  'HUMAN_AI_COLLABORATION',
  'ENTERPRISE_TRANSFORMATION',
] as const
