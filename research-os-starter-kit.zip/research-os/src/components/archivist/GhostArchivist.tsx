// ── Ghost Archivist Panel ─────────────────────────────────────────────────

import { useState, useRef, useEffect, KeyboardEvent } from 'react'
import { COLORS, FONTS } from '@/tokens'
import { MonoLabel } from '@/components/ui/primitives'
import { SUGGESTED_QUESTIONS } from '@/lib/archivist'
import { ArchivistMessage, Paper } from '@/types'

// ── Typing dots ───────────────────────────────────────────────────────────
function TypingDots() {
  return (
    <div style={{ display: 'flex', gap: 6, alignItems: 'center', marginLeft: 18 }}>
      {[0, 1, 2].map(i => (
        <div
          key={i}
          style={{
            width: 4,
            height: 4,
            borderRadius: '50%',
            background: COLORS.teal,
            animation: `pulse 0.8s ease-in-out infinite ${i * 0.15}s`,
          }}
        />
      ))}
    </div>
  )
}

// ── Message bubble ────────────────────────────────────────────────────────
function MessageBubble({ msg }: { msg: ArchivistMessage }) {
  const isArchivist = msg.role === 'assistant'
  return (
    <div
      style={{
        display: 'flex',
        justifyContent: isArchivist ? 'flex-start' : 'flex-end',
        animation: 'fadeInUp 0.2s ease',
      }}
    >
      {isArchivist && (
        <div style={{ marginRight: 12, marginTop: 6, flexShrink: 0 }}>
          <div
            style={{
              width: 6,
              height: 6,
              borderRadius: '50%',
              background: COLORS.teal,
              animation: 'breathe 3s ease-in-out infinite',
            }}
          />
        </div>
      )}
      <div
        style={{
          maxWidth: '72%',
          background: isArchivist ? 'transparent' : COLORS.bgSurf,
          border: isArchivist ? 'none' : `1px solid ${COLORS.border}`,
          borderLeft: isArchivist ? `2px solid ${COLORS.teal}40` : undefined,
          padding: isArchivist ? '4px 14px' : '10px 14px',
        }}
      >
        <p
          style={{
            fontFamily: isArchivist ? FONTS.body : FONTS.mono,
            fontSize: isArchivist ? 15 : 12,
            color: isArchivist ? COLORS.light : COLORS.mutedMid,
            fontStyle: isArchivist ? 'italic' : 'normal',
            lineHeight: 1.7,
            margin: 0,
            letterSpacing: isArchivist ? 'normal' : '0.05em',
          }}
        >
          {msg.content}
        </p>
      </div>
    </div>
  )
}

// ── Main panel ────────────────────────────────────────────────────────────

interface GhostArchivistProps {
  open: boolean
  loading: boolean
  messages: ArchivistMessage[]
  hoveredPaper: Paper | null
  papers: Paper[]
  onToggle: () => void
  onSend: (msg: string) => Promise<void>
}

export function GhostArchivist({
  open,
  loading,
  messages,
  hoveredPaper,
  papers,
  onToggle,
  onSend,
}: GhostArchivistProps) {
  const [input, setInput] = useState('')
  const msgEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (messages.length > 0) {
      msgEndRef.current?.scrollIntoView({ behavior: 'smooth' })
    }
  }, [messages])

  useEffect(() => {
    if (open) inputRef.current?.focus()
  }, [open])

  const handleSend = async () => {
    const msg = input.trim()
    if (!msg || loading) return
    setInput('')
    await onSend(msg)
  }

  const handleKey = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') void handleSend()
  }

  const totalSignals = papers.reduce((a, p) => a + p.signals.length, 0)

  return (
    <>
      {/* ── Anchor strip ──────────────────────────────────────────────── */}
      <div
        onClick={onToggle}
        style={{
          position: 'fixed',
          bottom: 0,
          left: 0,
          right: 0,
          background: open ? COLORS.bgMid : COLORS.bg,
          borderTop: `1px solid ${open ? `${COLORS.teal}50` : COLORS.borderMid}`,
          padding: '12px 40px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          cursor: 'pointer',
          zIndex: 100,
          transition: 'all 0.2s',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div
            style={{
              width: 7,
              height: 7,
              borderRadius: '50%',
              background: COLORS.teal,
              animation: 'breathe 3s ease-in-out infinite',
            }}
          />
          <MonoLabel color={COLORS.teal} size={9}>
            The Archivist
          </MonoLabel>
          {hoveredPaper && !open && (
            <span
              style={{
                fontFamily: FONTS.body,
                fontSize: 13,
                color: COLORS.muted,
                fontStyle: 'italic',
                marginLeft: 8,
              }}
            >
              — reading "{hoveredPaper.title.substring(0, 42)}
              {hoveredPaper.title.length > 42 ? '...' : ''}"
            </span>
          )}
        </div>
        <MonoLabel size={8}>
          {open ? 'Close ↓' : 'Ask the Library ↑'}
        </MonoLabel>
      </div>

      {/* ── Sliding panel ─────────────────────────────────────────────── */}
      <div
        style={{
          position: 'fixed',
          bottom: 41,
          left: 0,
          right: 0,
          height: open ? 400 : 0,
          background: COLORS.bgMid,
          borderTop: `1px solid ${COLORS.teal}40`,
          zIndex: 99,
          transition: 'height 0.4s cubic-bezier(0.16,1,0.3,1)',
          overflow: 'hidden',
          display: 'flex',
          flexDirection: 'column',
        }}
      >
        {open && (
          <>
            {/* Panel header */}
            <div
              style={{
                padding: '14px 40px',
                display: 'flex',
                gap: 32,
                alignItems: 'baseline',
                borderBottom: `1px solid ${COLORS.border}`,
                flexShrink: 0,
              }}
            >
              <div
                style={{
                  fontFamily: FONTS.serif,
                  fontStyle: 'italic',
                  fontSize: 16,
                  color: COLORS.cream,
                }}
              >
                The Archivist is attending.
              </div>
              <MonoLabel size={8}>
                {papers.length} Papers · {totalSignals} Signals Indexed
              </MonoLabel>
              {hoveredPaper && (
                <MonoLabel size={8} color={COLORS.teal}>
                  Context: {hoveredPaper.title.substring(0, 36)}...
                </MonoLabel>
              )}
            </div>

            {/* Messages */}
            <div
              style={{
                flex: 1,
                overflowY: 'auto',
                padding: '16px 40px',
                display: 'flex',
                flexDirection: 'column',
                gap: 14,
              }}
            >
              {messages.length === 0 && loading && <TypingDots />}
              {messages.map((msg, i) => (
                <MessageBubble key={i} msg={msg} />
              ))}
              {loading && messages.length > 0 && <TypingDots />}
              <div ref={msgEndRef} />
            </div>

            {/* Suggested prompts — show before first exchange */}
            {messages.length <= 1 && !loading && (
              <div
                style={{
                  padding: '0 40px 10px',
                  display: 'flex',
                  gap: 6,
                  flexWrap: 'wrap',
                  flexShrink: 0,
                }}
              >
                {SUGGESTED_QUESTIONS.slice(0, 4).map(q => (
                  <button
                    key={q}
                    onClick={() => void onSend(q)}
                    style={{
                      fontFamily: FONTS.mono,
                      fontSize: 8,
                      letterSpacing: '0.08em',
                      border: `1px solid ${COLORS.borderMid}`,
                      background: 'transparent',
                      color: COLORS.muted,
                      padding: '5px 10px',
                      cursor: 'pointer',
                      textAlign: 'left',
                      transition: 'all 0.15s',
                    }}
                    onMouseEnter={e => {
                      e.currentTarget.style.borderColor = COLORS.teal
                      e.currentTarget.style.color = COLORS.teal
                    }}
                    onMouseLeave={e => {
                      e.currentTarget.style.borderColor = COLORS.borderMid
                      e.currentTarget.style.color = COLORS.muted
                    }}
                  >
                    {q}
                  </button>
                ))}
              </div>
            )}

            {/* Input */}
            <div
              style={{
                borderTop: `1px solid ${COLORS.border}`,
                padding: '10px 40px',
                display: 'flex',
                gap: 12,
                flexShrink: 0,
              }}
            >
              <input
                ref={inputRef}
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={handleKey}
                placeholder="Ask the library anything..."
                style={{
                  flex: 1,
                  background: 'transparent',
                  border: 'none',
                  borderBottom: `1px solid ${COLORS.borderMid}`,
                  color: COLORS.light,
                  padding: '6px 0',
                  fontFamily: FONTS.body,
                  fontSize: 15,
                  fontStyle: 'italic',
                  outline: 'none',
                }}
              />
              <button
                onClick={() => void handleSend()}
                disabled={loading || !input.trim()}
                style={{
                  fontFamily: FONTS.mono,
                  fontSize: 8,
                  letterSpacing: '0.12em',
                  background: 'none',
                  border: `1px solid ${COLORS.teal}`,
                  color: COLORS.teal,
                  padding: '6px 14px',
                  cursor: 'pointer',
                  opacity: loading || !input.trim() ? 0.4 : 1,
                  textTransform: 'uppercase',
                }}
              >
                Send →
              </button>
            </div>
          </>
        )}
      </div>
    </>
  )
}
