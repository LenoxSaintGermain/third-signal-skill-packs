// ── LeftRail ──────────────────────────────────────────────────────────────

import { COLORS, FONTS } from '@/tokens'
import { MonoLabel } from '@/components/ui/primitives'
import { Paper, LibraryFilters, ClusterType, DepthType } from '@/types'

const CLUSTERS: Array<LibraryFilters['cluster']> = [
  'ALL',
  'AI_SYSTEMS',
  'PROFESSIONAL_IDENTITY',
  'GOVERNANCE',
  'HUMAN_AI_COLLABORATION',
  'ENTERPRISE_TRANSFORMATION',
]

const DEPTHS: Array<LibraryFilters['depth']> = ['ALL', 'SURFACE', 'DEEP', 'FULL_IMMERSION']

const CLUSTER_LABELS: Record<string, string> = {
  ALL: 'All',
  AI_SYSTEMS: 'AI Systems',
  PROFESSIONAL_IDENTITY: 'Professional Identity',
  GOVERNANCE: 'Governance',
  HUMAN_AI_COLLABORATION: 'Human-AI Collab',
  ENTERPRISE_TRANSFORMATION: 'Enterprise',
}

const DEPTH_LABELS: Record<string, string> = {
  ALL: 'All Depths',
  SURFACE: 'Surface',
  DEEP: 'Deep',
  FULL_IMMERSION: 'Full Immersion',
}

interface LeftRailProps {
  filters: LibraryFilters
  papers: Paper[]
  onCluster: (c: LibraryFilters['cluster']) => void
  onDepth: (d: LibraryFilters['depth']) => void
}

export function LeftRail({ filters, papers, onCluster, onDepth }: LeftRailProps) {
  const signalCounts = papers.reduce<Record<string, number>>((acc, p) => {
    acc[p.id] = p.signals.length
    return acc
  }, {})

  return (
    <div
      style={{
        borderRight: `1px solid ${COLORS.border}`,
        padding: '28px 0',
        position: 'sticky',
        top: 50,
        height: 'calc(100vh - 50px)',
        overflowY: 'auto',
        flexShrink: 0,
        width: 180,
      }}
    >
      {/* Cluster filter */}
      <div
        style={{
          fontFamily: FONTS.mono,
          fontSize: 8,
          color: COLORS.muted,
          letterSpacing: '0.16em',
          padding: '0 20px 12px',
          textTransform: 'uppercase',
        }}
      >
        Cluster
      </div>

      {CLUSTERS.map(c => (
        <button
          key={c}
          onClick={() => onCluster(c)}
          style={{
            display: 'block',
            width: '100%',
            textAlign: 'left',
            padding: '10px 20px',
            background: 'none',
            border: 'none',
            borderLeft: `2px solid ${filters.cluster === c ? COLORS.teal : 'transparent'}`,
            fontFamily: FONTS.mono,
            fontSize: 8,
            color: filters.cluster === c ? COLORS.teal : COLORS.muted,
            letterSpacing: '0.1em',
            cursor: 'pointer',
            transition: 'all 0.15s',
            textTransform: 'uppercase',
          }}
        >
          {CLUSTER_LABELS[c] ?? c}
        </button>
      ))}

      <div style={{ height: 1, background: COLORS.border, margin: '16px 20px' }} />

      {/* Depth filter */}
      <div
        style={{
          fontFamily: FONTS.mono,
          fontSize: 8,
          color: COLORS.muted,
          letterSpacing: '0.16em',
          padding: '0 20px 12px',
          textTransform: 'uppercase',
        }}
      >
        Depth
      </div>

      {DEPTHS.map(d => (
        <button
          key={d}
          onClick={() => onDepth(d)}
          style={{
            display: 'block',
            width: '100%',
            textAlign: 'left',
            padding: '10px 20px',
            background: 'none',
            border: 'none',
            borderLeft: `2px solid ${filters.depth === d ? COLORS.amber : 'transparent'}`,
            fontFamily: FONTS.mono,
            fontSize: 8,
            color: filters.depth === d ? COLORS.amber : COLORS.muted,
            letterSpacing: '0.1em',
            cursor: 'pointer',
            transition: 'all 0.15s',
            textTransform: 'uppercase',
          }}
        >
          {DEPTH_LABELS[d] ?? d}
        </button>
      ))}

      <div style={{ height: 1, background: COLORS.border, margin: '16px 20px' }} />

      {/* Signal counts per paper */}
      <div style={{ padding: '0 20px' }}>
        <MonoLabel style={{ display: 'block', marginBottom: 8 }}>Signals</MonoLabel>
        {papers.map(p => (
          <div
            key={p.id}
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              marginBottom: 6,
              alignItems: 'center',
            }}
          >
            <MonoLabel size={7} style={{ letterSpacing: '0.06em' }}>
              {p.issue}
            </MonoLabel>
            <MonoLabel size={7} color={p.accentColor ?? COLORS.teal}>
              {signalCounts[p.id] ?? 0}
            </MonoLabel>
          </div>
        ))}
      </div>
    </div>
  )
}
