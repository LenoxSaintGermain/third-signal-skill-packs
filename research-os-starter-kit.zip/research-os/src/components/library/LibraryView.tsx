// ── LibraryView — Main Page ───────────────────────────────────────────────

import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { COLORS, FONTS } from '@/tokens'
import { MonoLabel, SkeletonCard, SeedModeBanner } from '@/components/ui/primitives'
import { TopBar } from '@/components/library/TopBar'
import { LeftRail } from '@/components/library/LeftRail'
import { FeaturedPaper, PaperCard } from '@/components/library/PaperCards'
import { GhostArchivist } from '@/components/archivist/GhostArchivist'
import { IngestModal } from '@/components/ingest/IngestModal'
import { usePapers } from '@/hooks/usePapers'
import { useArchivist } from '@/hooks/useArchivist'
import { isSeedMode } from '@/lib/api'
import { Paper } from '@/types'

export function LibraryView() {
  const navigate = useNavigate()
  const { papers, featured, grid, loading, error, filters, setCluster, setDepth } = usePapers()
  const [showIngest, setShowIngest] = useState(false)

  const archivist = useArchivist({
    papers,
    activeCluster: filters.cluster,
  })

  const handlePaperClick = (paper: Paper) => {
    navigate(`/paper/${paper.id}`)

  }

  return (
    <div
      style={{
        background: COLORS.bg,
        minHeight: '100vh',
        paddingBottom: 120,
        display: 'flex',
        flexDirection: 'column',
      }}
    >
      {/* Seed mode banner */}
      {isSeedMode() && <SeedModeBanner />}

      {/* Top bar */}
      <TopBar
        paperCount={papers.length}
        onIngest={() => setShowIngest(true)}
      />

      {/* Main layout */}
      <div style={{ display: 'flex', flex: 1 }}>

        {/* Left rail */}
        <LeftRail
          filters={filters}
          papers={papers}
          onCluster={setCluster}
          onDepth={setDepth}
        />

        {/* Content area */}
        <div style={{ flex: 1, minWidth: 0 }}>

          {/* Error state */}
          {error && (
            <div style={{ padding: '40px 32px' }}>
              <div
                style={{
                  fontFamily: FONTS.mono,
                  fontSize: 10,
                  color: COLORS.risk,
                  letterSpacing: '0.12em',
                  marginBottom: 8,
                }}
              >
                ERROR
              </div>
              <p style={{ fontFamily: FONTS.body, color: COLORS.muted, fontSize: 15 }}>{error}</p>
            </div>
          )}

          {/* Featured paper */}
          {!loading && !error && featured && filters.cluster === 'ALL' && (
            <FeaturedPaper paper={featured} onClick={handlePaperClick} />
          )}

          {/* Section header */}
          {!loading && !error && (
            <div
              style={{
                padding: '18px 32px 14px',
                borderBottom: `1px solid ${COLORS.border}`,
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
              }}
            >
              <MonoLabel size={8}>
                {filters.cluster === 'ALL' ? 'Full Archive' : filters.cluster.replace('_', ' ')}
                {' · '}
                {grid.length} Paper{grid.length !== 1 ? 's' : ''}
              </MonoLabel>
              <div style={{ display: 'flex', gap: 8 }}>
                {(['Chronological', 'By Depth', 'By Signal Count'] as const).map(s => (
                  <button
                    key={s}
                    style={{
                      fontFamily: FONTS.mono,
                      fontSize: 7,
                      letterSpacing: '0.1em',
                      border: `1px solid ${COLORS.border}`,
                      background: 'transparent',
                      color: COLORS.muted,
                      padding: '4px 10px',
                      cursor: 'pointer',
                      textTransform: 'uppercase',
                    }}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Loading skeletons */}
          {loading && (
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(2, 1fr)',
                gap: 1,
                background: COLORS.border,
                margin: '1px 0',
              }}
            >
              {[1, 2, 3, 4].map(i => <SkeletonCard key={i} />)}
            </div>
          )}

          {/* Paper grid */}
          {!loading && !error && grid.length > 0 && (
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(2, 1fr)',
                gap: 1,
                background: COLORS.border,
                margin: '1px 0',
              }}
            >
              {grid.map(paper => (
                <PaperCard
                  key={paper.id}
                  paper={paper}
                  onHover={archivist.setHoveredPaper}
                  isHighlighted={archivist.hoveredPaper?.id === paper.id}
                  onClick={handlePaperClick}
                />
              ))}
            </div>
          )}

          {/* Empty state */}
          {!loading && !error && grid.length === 0 && (
            <div style={{ padding: '80px 32px', textAlign: 'center' }}>
              <div
                style={{
                  fontFamily: FONTS.serif,
                  fontSize: 20,
                  fontStyle: 'italic',
                  color: COLORS.muted,
                  marginBottom: 16,
                }}
              >
                No papers in this cluster yet.
              </div>
              <button
                onClick={() => setShowIngest(true)}
                style={{
                  fontFamily: FONTS.mono,
                  fontSize: 9,
                  letterSpacing: '0.12em',
                  border: `1px solid ${COLORS.teal}`,
                  color: COLORS.teal,
                  background: 'transparent',
                  padding: '9px 20px',
                  cursor: 'pointer',
                  textTransform: 'uppercase',
                }}
              >
                + Ingest the First Paper
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Ghost Archivist */}
      <GhostArchivist
        open={archivist.open}
        loading={archivist.loading}
        messages={archivist.messages}
        hoveredPaper={archivist.hoveredPaper}
        papers={papers}
        onToggle={() => void archivist.toggle()}
        onSend={msg => archivist.sendMessage(msg)}
      />

      {/* Ingest modal */}
      {showIngest && <IngestModal onClose={() => setShowIngest(false)} />}
    </div>
  )
}
