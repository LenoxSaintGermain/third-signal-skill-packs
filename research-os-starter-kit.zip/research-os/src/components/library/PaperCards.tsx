// ── Paper Cards ───────────────────────────────────────────────────────────

import { useState } from 'react'
import { COLORS, FONTS, TRANSITIONS } from '@/tokens'
import { Tag, MonoLabel } from '@/components/ui/primitives'
import { Paper } from '@/types'

// ── PaperCard ─────────────────────────────────────────────────────────────

interface PaperCardProps {
  paper: Paper
  onHover: (paper: Paper | null) => void
  isHighlighted: boolean
  onClick: (paper: Paper) => void
}

export function PaperCard({ paper, onHover, isHighlighted, onClick }: PaperCardProps) {
  const accent = paper.accentColor ?? COLORS.teal

  return (
    <div
      onMouseEnter={() => onHover(paper)}
      onMouseLeave={() => onHover(null)}
      onClick={() => onClick(paper)}
      style={{
        background: isHighlighted ? COLORS.bgSurf : COLORS.bgCard,
        border: `1px solid ${isHighlighted ? `${accent}60` : COLORS.border}`,
        padding: 24,
        cursor: 'pointer',
        transition: TRANSITIONS.normal,
        transform: isHighlighted ? 'translateY(-3px)' : 'none',
        boxShadow: isHighlighted
          ? `0 12px 32px rgba(0,0,0,0.4), 0 0 0 1px ${accent}30`
          : 'none',
        position: 'relative',
        overflow: 'hidden',
      }}
    >
      {/* Top border reveal on hover */}
      <div
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          height: 2,
          width: isHighlighted ? '100%' : '0%',
          background: accent,
          transition: 'width 0.28s ease',
        }}
      />

      {/* Issue + depth */}
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: 16,
        }}
      >
        <MonoLabel color={accent} size={9}>
          Paper {paper.issue}
        </MonoLabel>
        <MonoLabel size={8}>{paper.depth.replace('_', ' ')}</MonoLabel>
      </div>

      {/* Cluster */}
      <MonoLabel
        size={8}
        color={accent}
        style={{ opacity: 0.7, display: 'block', marginBottom: 8 }}
      >
        {paper.cluster.replace('_', ' ')}
      </MonoLabel>

      {/* Title */}
      <h3
        style={{
          fontFamily: FONTS.serif,
          fontSize: 18,
          fontWeight: 700,
          color: COLORS.cream,
          lineHeight: 1.25,
          marginBottom: 10,
        }}
      >
        {paper.title}
      </h3>

      {/* Abstract */}
      <p
        style={{
          fontFamily: FONTS.body,
          fontSize: 14,
          color: COLORS.muted,
          lineHeight: 1.65,
          marginBottom: 16,
          display: '-webkit-box',
          WebkitLineClamp: 3,
          WebkitBoxOrient: 'vertical',
          overflow: 'hidden',
        }}
      >
        {paper.abstract}
      </p>

      {/* Tags */}
      <div
        style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 16 }}
      >
        {paper.tags.slice(0, 3).map(tag => (
          <Tag key={tag} label={tag} />
        ))}
      </div>

      {/* Meta footer */}
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          borderTop: `1px solid ${COLORS.border}`,
          paddingTop: 12,
        }}
      >
        <div style={{ display: 'flex', gap: 16 }}>
          {([
            [paper.sections.length || '—', 'Sections'],
            [paper.signals.length, 'Signals'],
            [paper.citations.length || '—', 'Cites'],
          ] as [string | number, string][]).map(([n, label]) => (
            <div key={label} style={{ textAlign: 'center' }}>
              <div
                style={{
                  fontFamily: FONTS.mono,
                  fontSize: 11,
                  color: COLORS.light,
                  fontWeight: 700,
                }}
              >
                {n}
              </div>
              <div
                style={{
                  fontFamily: FONTS.mono,
                  fontSize: 7,
                  color: COLORS.muted,
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                }}
              >
                {label}
              </div>
            </div>
          ))}
        </div>
        <MonoLabel size={8}>
          {paper.readTime} · {paper.date}
        </MonoLabel>
      </div>
    </div>
  )
}

// ── FeaturedPaper ─────────────────────────────────────────────────────────

interface FeaturedPaperProps {
  paper: Paper
  onClick: (paper: Paper) => void
}

export function FeaturedPaper({ paper, onClick }: FeaturedPaperProps) {
  const [hov, setHov] = useState(false)

  return (
    <div
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      onClick={() => onClick(paper)}
      style={{
        background: COLORS.bgSurf,
        border: `1px solid ${hov ? `${COLORS.teal}60` : COLORS.borderMid}`,
        padding: '48px 52px',
        cursor: 'pointer',
        position: 'relative',
        overflow: 'hidden',
        transition: TRANSITIONS.normal,
        marginBottom: 2,
        minHeight: 320,
      }}
    >
      {/* Atmospheric grid bg */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          opacity: 0.04,
          backgroundImage: `
            repeating-linear-gradient(0deg, transparent, transparent 39px, ${COLORS.teal} 39px, ${COLORS.teal} 40px),
            repeating-linear-gradient(90deg, transparent, transparent 39px, ${COLORS.teal} 39px, ${COLORS.teal} 40px)
          `,
        }}
      />

      <div
        style={{
          position: 'relative',
          zIndex: 1,
          maxWidth: 660,
        }}
      >
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 16,
            marginBottom: 20,
          }}
        >
          <MonoLabel color={COLORS.teal} size={9}>
            ◆ Featured · Paper {paper.issue}
          </MonoLabel>
          <MonoLabel size={8}>{paper.cluster.replace('_', ' ')}</MonoLabel>
        </div>

        <h2
          style={{
            fontFamily: FONTS.serif,
            fontSize: 38,
            fontWeight: 900,
            color: COLORS.cream,
            lineHeight: 1.1,
            marginBottom: 12,
            letterSpacing: '-0.4px',
          }}
        >
          {paper.title}
        </h2>

        <p
          style={{
            fontFamily: FONTS.serif,
            fontStyle: 'italic',
            fontSize: 17,
            color: COLORS.mutedMid,
            marginBottom: 24,
            lineHeight: 1.45,
          }}
        >
          {paper.subtitle}
        </p>

        <p
          style={{
            fontFamily: FONTS.body,
            fontSize: 15,
            color: COLORS.muted,
            lineHeight: 1.75,
            marginBottom: 32,
            maxWidth: 560,
          }}
        >
          {paper.abstract}
        </p>

        <div style={{ display: 'flex', gap: 16, alignItems: 'center' }}>
          <button
            style={{
              fontFamily: FONTS.mono,
              fontSize: 10,
              letterSpacing: '0.14em',
              background: COLORS.teal,
              border: 'none',
              color: COLORS.bg,
              padding: '12px 28px',
              cursor: 'pointer',
              textTransform: 'uppercase',
            }}
          >
            Enter Paper →
          </button>
          <MonoLabel size={8}>
            {paper.readTime} · {paper.depth.replace('_', ' ')}
          </MonoLabel>
        </div>
      </div>

      {/* Signal strip — right side */}
      <div
        style={{
          position: 'absolute',
          right: 52,
          top: 48,
          bottom: 48,
          width: 210,
          borderLeft: `1px solid ${COLORS.borderMid}`,
          paddingLeft: 24,
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'center',
          gap: 14,
        }}
      >
        <MonoLabel color={COLORS.teal} size={8} style={{ display: 'block', marginBottom: 4 }}>
          Signals Extracted
        </MonoLabel>
        {paper.signals.slice(0, 3).map(sig => (
          <div
            key={sig.id}
            style={{ borderLeft: `2px solid ${COLORS.teal}30`, paddingLeft: 10 }}
          >
            <p
              style={{
                fontFamily: FONTS.body,
                fontStyle: 'italic',
                fontSize: 12,
                color: COLORS.mutedMid,
                lineHeight: 1.55,
                margin: 0,
              }}
            >
              "{sig.content}"
            </p>
          </div>
        ))}
      </div>
    </div>
  )
}
