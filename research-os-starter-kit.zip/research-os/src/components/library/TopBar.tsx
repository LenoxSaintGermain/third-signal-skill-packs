// ── TopBar ────────────────────────────────────────────────────────────────

import { useNavigate } from 'react-router-dom'
import { COLORS, FONTS } from '@/tokens'
import { MonoLabel } from '@/components/ui/primitives'
import { isSeedMode } from '@/lib/api'

interface TopBarProps {
  paperCount: number
  onIngest: () => void
}

export function TopBar({ paperCount, onIngest }: TopBarProps) {
  const navigate = useNavigate()
  const seed = isSeedMode()

  return (
    <div
      style={{
        background: COLORS.bgMid,
        borderBottom: `1px solid ${COLORS.border}`,
        padding: '14px 40px',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        position: 'sticky',
        top: 0,
        zIndex: 50,
        flexShrink: 0,
      }}
    >
      {/* Left — identity */}
      <div style={{ display: 'flex', gap: 24, alignItems: 'center' }}>
        <div>
          <div
            style={{
              fontFamily: FONTS.mono,
              fontSize: 10,
              fontWeight: 700,
              color: COLORS.cream,
              letterSpacing: '0.14em',
              textTransform: 'uppercase',
            }}
          >
            Third Signal Labs
          </div>
          <div
            style={{
              fontFamily: FONTS.mono,
              fontSize: 8,
              color: COLORS.mutedMid,
              letterSpacing: '0.12em',
              marginTop: 1,
            }}
          >
            Research Archive · {paperCount} Published Paper{paperCount !== 1 ? 's' : ''}
            {seed && ' · SEED MODE'}
          </div>
        </div>

        <div style={{ width: 1, height: 28, background: COLORS.border }} />

        <div
          style={{
            fontFamily: FONTS.serif,
            fontSize: 16,
            fontStyle: 'italic',
            color: COLORS.mutedMid,
          }}
        >
          Research OS
        </div>
      </div>

      {/* Right — actions */}
      <div style={{ display: 'flex', gap: 10 }}>
        <button
          onClick={onIngest}
          style={{
            fontFamily: FONTS.mono,
            fontSize: 9,
            letterSpacing: '0.12em',
            border: `1px solid ${COLORS.teal}`,
            color: COLORS.teal,
            background: 'transparent',
            padding: '7px 16px',
            cursor: 'pointer',
            textTransform: 'uppercase',
            transition: 'all 0.15s',
          }}
          onMouseEnter={e => {
            const el = e.currentTarget
            el.style.background = COLORS.tealBg
          }}
          onMouseLeave={e => {
            const el = e.currentTarget
            el.style.background = 'transparent'
          }}
        >
          + Ingest Paper
        </button>

        <button
          style={{
            fontFamily: FONTS.mono,
            fontSize: 9,
            letterSpacing: '0.12em',
            border: `1px solid ${COLORS.border}`,
            color: COLORS.mutedMid,
            background: 'transparent',
            padding: '7px 16px',
            cursor: 'pointer',
            textTransform: 'uppercase',
            onClick: () => navigate('/signals'),
          }}
        >
          Signal Graph
        </button>
      </div>
    </div>
  )
}
