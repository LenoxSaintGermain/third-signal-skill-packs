// ── IngestModal ───────────────────────────────────────────────────────────

import { useState, DragEvent } from 'react'
import { COLORS, FONTS } from '@/tokens'
import { MonoLabel } from '@/components/ui/primitives'
import { ingestArtifact } from '@/lib/api'
import { IngestSourceType } from '@/types'

type ModalMode = 'choose' | 'processing' | 'done'

const PIPELINE_STAGES = [
  { id: 'ingest',   label: 'Ingesting Source',         detail: 'Extracting raw text and structure...' },
  { id: 'parse',    label: 'Parsing Section Types',    detail: 'Detecting thesis, argument, evidence, signal blocks...' },
  { id: 'signals',  label: 'Extracting Signals',       detail: 'Isolating extractable insight statements...' },
  { id: 'diagrams', label: 'Flagging Diagram Zones',   detail: 'Identifying concepts that want visual treatment...' },
  { id: 'enrich',   label: 'Enriching with Context',   detail: 'Cross-referencing existing library signals...' },
  { id: 'tensions', label: 'Detecting Tensions',       detail: 'Scanning for contradictions with existing papers...' },
  { id: 'index',    label: 'Indexing to Signal Graph', detail: 'Registering nodes and relationships...' },
  { id: 'ready',    label: 'Paper Ready',              detail: 'Entering the archive.' },
]

interface SourceOption {
  id: IngestSourceType
  label: string
  sub: string
}

const SOURCE_OPTIONS: SourceOption[] = [
  { id: 'gdoc',     label: 'Google Doc',  sub: 'Paste a shareable URL' },
  { id: 'pdf',      label: 'PDF Upload',  sub: 'Drag or browse' },
  { id: 'markdown', label: 'Markdown',    sub: 'Paste .md content' },
  { id: 'raw_text', label: 'Raw Text',    sub: 'Paste anything' },
]

interface IngestModalProps {
  onClose: () => void
}

export function IngestModal({ onClose }: IngestModalProps) {
  const [mode, setMode] = useState<ModalMode>('choose')
  const [sourceType, setSourceType] = useState<IngestSourceType | null>(null)
  const [url, setUrl] = useState('')
  const [content, setContent] = useState('')
  const [dragOver, setDragOver] = useState(false)
  const [progress, setProgress] = useState<string[]>([])

  const simulate = async () => {
    setMode('processing')
    setProgress([])

    // Kick off real API call (or seed mode simulation)
    void ingestArtifact({
      content: content || url || 'Demo content',
      sourceType: sourceType ?? 'raw_text',
      sourceUrl: sourceType === 'gdoc' ? url : undefined,
    })

    // Animate pipeline stages
    PIPELINE_STAGES.forEach((stage, i) => {
      setTimeout(() => {
        setProgress(prev => [...prev, stage.id])
        if (i === PIPELINE_STAGES.length - 1) {
          setTimeout(() => setMode('done'), 600)
        }
      }, i * 620)
    })
  }

  const handleDrop = (e: DragEvent) => {
    e.preventDefault()
    setDragOver(false)
    // In production: read e.dataTransfer.files[0]
  }

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        background: 'rgba(0,0,0,0.85)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 200,
        backdropFilter: 'blur(4px)',
      }}
      onClick={onClose}
    >
      <div
        onClick={e => e.stopPropagation()}
        style={{
          background: COLORS.bgMid,
          border: `1px solid ${COLORS.borderMid}`,
          width: 560,
          maxHeight: '85vh',
          overflowY: 'auto',
        }}
      >
        {/* Header */}
        <div
          style={{
            borderBottom: `1px solid ${COLORS.border}`,
            padding: '16px 24px',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}
        >
          <div>
            <MonoLabel color={COLORS.teal} size={8} style={{ display: 'block', marginBottom: 3 }}>
              Third Signal Labs · Research OS
            </MonoLabel>
            <div
              style={{
                fontFamily: FONTS.serif,
                fontSize: 18,
                fontWeight: 700,
                color: COLORS.cream,
              }}
            >
              Ingest Research
            </div>
          </div>
          <button
            onClick={onClose}
            style={{
              background: 'none',
              border: 'none',
              color: COLORS.muted,
              cursor: 'pointer',
              fontFamily: FONTS.mono,
              fontSize: 9,
              letterSpacing: '0.12em',
              textTransform: 'uppercase',
            }}
          >
            Close ×
          </button>
        </div>

        <div style={{ padding: '28px 24px' }}>

          {/* ── CHOOSE mode ───────────────────────────────────────────── */}
          {mode === 'choose' && (
            <>
              <p
                style={{
                  fontFamily: FONTS.body,
                  fontSize: 15,
                  color: COLORS.muted,
                  lineHeight: 1.65,
                  marginBottom: 24,
                }}
              >
                Drop a paper in any format. The system parses section types, extracts signals, detects diagram candidates, and cross-references existing library tensions automatically.
              </p>

              {/* Source type grid */}
              <div
                style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 24 }}
              >
                {SOURCE_OPTIONS.map(opt => (
                  <div
                    key={opt.id}
                    onClick={() => setSourceType(opt.id)}
                    style={{
                      border: `1px solid ${sourceType === opt.id ? COLORS.teal : COLORS.border}`,
                      background: sourceType === opt.id ? COLORS.tealBg : 'transparent',
                      padding: '14px 16px',
                      cursor: 'pointer',
                      transition: 'all 0.15s',
                    }}
                  >
                    <MonoLabel
                      color={sourceType === opt.id ? COLORS.teal : COLORS.mutedMid}
                      size={9}
                      style={{ display: 'block', marginBottom: 4 }}
                    >
                      {opt.label}
                    </MonoLabel>
                    <p
                      style={{
                        fontFamily: FONTS.body,
                        fontSize: 13,
                        color: COLORS.muted,
                        fontStyle: 'italic',
                        margin: 0,
                      }}
                    >
                      {opt.sub}
                    </p>
                  </div>
                ))}
              </div>

              {/* Conditional input */}
              {sourceType === 'gdoc' && (
                <div style={{ marginBottom: 20 }}>
                  <MonoLabel color={COLORS.teal} size={8} style={{ display: 'block', marginBottom: 8 }}>
                    Google Doc URL
                  </MonoLabel>
                  <input
                    value={url}
                    onChange={e => setUrl(e.target.value)}
                    placeholder="https://docs.google.com/document/d/..."
                    style={{
                      width: '100%',
                      background: COLORS.bg,
                      border: `1px solid ${COLORS.borderMid}`,
                      color: COLORS.light,
                      padding: '10px 12px',
                      fontFamily: FONTS.mono,
                      fontSize: 11,
                      outline: 'none',
                    }}
                  />
                </div>
              )}

              {(sourceType === 'markdown' || sourceType === 'raw_text') && (
                <div style={{ marginBottom: 20 }}>
                  <MonoLabel color={COLORS.teal} size={8} style={{ display: 'block', marginBottom: 8 }}>
                    {sourceType === 'markdown' ? 'Markdown Content' : 'Raw Text'}
                  </MonoLabel>
                  <textarea
                    value={content}
                    onChange={e => setContent(e.target.value)}
                    placeholder={sourceType === 'markdown' ? '# Paper Title\n\n## Abstract\n...' : 'Paste research content here...'}
                    rows={8}
                    style={{
                      width: '100%',
                      background: COLORS.bg,
                      border: `1px solid ${COLORS.borderMid}`,
                      color: COLORS.light,
                      padding: '10px 12px',
                      fontFamily: FONTS.mono,
                      fontSize: 11,
                      outline: 'none',
                      resize: 'vertical',
                    }}
                  />
                </div>
              )}

              {sourceType === 'pdf' && (
                <div
                  onDragOver={e => { e.preventDefault(); setDragOver(true) }}
                  onDragLeave={() => setDragOver(false)}
                  onDrop={handleDrop}
                  style={{
                    border: `2px dashed ${dragOver ? COLORS.teal : COLORS.borderMid}`,
                    background: dragOver ? COLORS.tealBg : 'transparent',
                    padding: 40,
                    textAlign: 'center',
                    marginBottom: 20,
                    transition: 'all 0.2s',
                    cursor: 'pointer',
                  }}
                >
                  <MonoLabel size={9} style={{ display: 'block', marginBottom: 8 }}>
                    Drop PDF Here
                  </MonoLabel>
                  <p style={{ fontFamily: FONTS.body, fontSize: 13, color: COLORS.muted, fontStyle: 'italic', margin: 0 }}>
                    or click to browse
                  </p>
                </div>
              )}

              {/* Submit */}
              <button
                onClick={() => void simulate()}
                disabled={!sourceType}
                style={{
                  width: '100%',
                  padding: 14,
                  fontFamily: FONTS.mono,
                  fontSize: 10,
                  letterSpacing: '0.14em',
                  background: sourceType ? COLORS.teal : COLORS.border,
                  border: 'none',
                  color: sourceType ? COLORS.bg : COLORS.muted,
                  cursor: sourceType ? 'pointer' : 'not-allowed',
                  textTransform: 'uppercase',
                  transition: 'all 0.2s',
                }}
              >
                Begin Ingestion →
              </button>
            </>
          )}

          {/* ── PROCESSING mode ────────────────────────────────────────── */}
          {mode === 'processing' && (
            <div>
              <div style={{ fontFamily: FONTS.serif, fontSize: 20, fontWeight: 700, color: COLORS.cream, marginBottom: 8, fontStyle: 'italic' }}>
                Processing your research.
              </div>
              <p style={{ fontFamily: FONTS.body, fontSize: 14, color: COLORS.muted, marginBottom: 28, lineHeight: 1.6 }}>
                The pipeline is reading, parsing, and connecting your paper to the existing body of work.
              </p>
              <div style={{ display: 'flex', flexDirection: 'column' }}>
                {PIPELINE_STAGES.map((stage, i) => {
                  const done = progress.includes(stage.id)
                  const active = progress.length === i
                  return (
                    <div
                      key={stage.id}
                      style={{
                        display: 'flex',
                        gap: 14,
                        alignItems: 'flex-start',
                        padding: '11px 0',
                        borderBottom: i < PIPELINE_STAGES.length - 1 ? `1px solid ${COLORS.border}` : 'none',
                        opacity: done || active ? 1 : 0.3,
                        transition: 'opacity 0.3s',
                      }}
                    >
                      <div style={{
                        width: 18, height: 18, borderRadius: '50%', flexShrink: 0, marginTop: 2,
                        border: `1px solid ${done ? COLORS.teal : active ? COLORS.amber : COLORS.border}`,
                        background: done ? COLORS.teal : 'transparent',
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        transition: 'all 0.3s',
                      }}>
                        {done && <span style={{ color: COLORS.bg, fontSize: 9, fontWeight: 700 }}>✓</span>}
                        {active && <span style={{ color: COLORS.amber, fontSize: 7, animation: 'pulse 1s infinite' }}>●</span>}
                      </div>
                      <div>
                        <MonoLabel
                          size={9}
                          color={done ? COLORS.teal : active ? COLORS.amber : COLORS.muted}
                          style={{ display: 'block', marginBottom: 2 }}
                        >
                          {stage.label}
                        </MonoLabel>
                        <p style={{ fontFamily: FONTS.body, fontSize: 13, color: COLORS.muted, fontStyle: 'italic', margin: 0 }}>
                          {stage.detail}
                        </p>
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
          )}

          {/* ── DONE mode ──────────────────────────────────────────────── */}
          {mode === 'done' && (
            <div style={{ textAlign: 'center', padding: '20px 0' }}>
              <div style={{ fontSize: 36, marginBottom: 16, color: COLORS.teal }}>◆</div>
              <div style={{ fontFamily: FONTS.serif, fontSize: 24, fontWeight: 700, color: COLORS.teal, marginBottom: 8 }}>
                Paper archived.
              </div>
              <p style={{ fontFamily: FONTS.body, fontSize: 15, color: COLORS.muted, lineHeight: 1.7, marginBottom: 8 }}>
                The Archivist has been notified. Signals are indexed. Tensions detected and registered.
              </p>
              <p style={{ fontFamily: FONTS.body, fontSize: 13, color: COLORS.muted, fontStyle: 'italic', lineHeight: 1.6, marginBottom: 28 }}>
                "The library has something new to say."
              </p>
              <button
                onClick={onClose}
                style={{
                  fontFamily: FONTS.mono, fontSize: 10, letterSpacing: '0.14em',
                  background: COLORS.teal, border: 'none', color: COLORS.bg,
                  padding: '12px 28px', cursor: 'pointer', textTransform: 'uppercase',
                }}
              >
                Enter Archive →
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
