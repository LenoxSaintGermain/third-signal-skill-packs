// ── Shared UI Primitives ──────────────────────────────────────────────────

import { CSSProperties, ReactNode } from 'react'
import { COLORS, FONTS } from '@/tokens'

// ── MonoLabel ─────────────────────────────────────────────────────────────
interface MonoLabelProps {
  children: ReactNode
  color?: string
  size?: number
  bold?: boolean
  style?: CSSProperties
}

export function MonoLabel({
  children,
  color = COLORS.muted,
  size = 9,
  bold = false,
  style,
}: MonoLabelProps) {
  return (
    <span
      style={{
        fontFamily: FONTS.mono,
        fontSize: size,
        color,
        letterSpacing: '0.13em',
        fontWeight: bold ? 700 : 400,
        textTransform: 'uppercase',
        ...style,
      }}
    >
      {children}
    </span>
  )
}

// ── Tag ───────────────────────────────────────────────────────────────────
interface TagProps {
  label: string
  color?: string
}

export function Tag({ label, color = COLORS.muted }: TagProps) {
  return (
    <span
      style={{
        fontFamily: FONTS.mono,
        fontSize: 7,
        color,
        letterSpacing: '0.1em',
        border: `1px solid ${COLORS.border}`,
        padding: '3px 8px',
        whiteSpace: 'nowrap',
      }}
    >
      {label}
    </span>
  )
}

// ── Divider ───────────────────────────────────────────────────────────────
export function Divider({ margin = '0 0 16px' }: { margin?: string }) {
  return (
    <div
      style={{
        width: '100%',
        height: 1,
        background: COLORS.border,
        margin,
      }}
    />
  )
}

// ── SkeletonCard ──────────────────────────────────────────────────────────
export function SkeletonCard() {
  return (
    <div
      style={{
        background: COLORS.bgCard,
        padding: 24,
        border: `1px solid ${COLORS.border}`,
      }}
    >
      {[80, 200, 120, 160, 80].map((width, i) => (
        <div
          key={i}
          style={{
            height: i === 1 ? 20 : 12,
            width,
            background: `linear-gradient(90deg, ${COLORS.bgSurf} 25%, ${COLORS.bgMid} 50%, ${COLORS.bgSurf} 75%)`,
            backgroundSize: '400px 100%',
            animation: 'shimmer 1.4s ease-in-out infinite',
            marginBottom: i === 4 ? 0 : 12,
            borderRadius: 2,
          }}
        />
      ))}
    </div>
  )
}

// ── SeedModeBanner ────────────────────────────────────────────────────────
export function SeedModeBanner() {
  return (
    <div
      style={{
        background: COLORS.amberBg,
        border: `1px solid ${COLORS.amber}30`,
        borderLeft: `3px solid ${COLORS.amber}`,
        padding: '8px 16px',
        margin: '0 0 0',
      }}
    >
      <MonoLabel color={COLORS.amber} size={8}>
        SEED MODE — Set VITE_RESEARCH_OS_BASE_URL in .env.local to connect the live API
      </MonoLabel>
    </div>
  )
}
