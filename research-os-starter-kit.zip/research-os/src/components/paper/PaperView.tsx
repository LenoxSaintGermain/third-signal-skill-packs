// ── PaperView — Full Paper Experience ────────────────────────────────────
// Renders all 9 section types, sticky nav rail, reading depth indicator,
// signal strip, and inline Archivist context for the current paper.

import { useState, useEffect, useRef, useCallback } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { COLORS, FONTS, TRANSITIONS } from '@/tokens'
import { MonoLabel, Tag, Divider } from '@/components/ui/primitives'
import { GhostArchivist } from '@/components/archivist/GhostArchivist'
import { useArchivist } from '@/hooks/useArchivist'
import { getPaper, listPapers } from '@/lib/api'
import { Paper, PaperSection, Signal, SectionType } from '@/types'

// ── Section type config ────────────────────────────────────────────────────

const SECTION_CONFIG: Record<SectionType, { label: string; accent: string; italic?: boolean }> = {
  THESIS:      { label: 'Thesis',       accent: COLORS.teal,     italic: false },
  ARGUMENT:    { label: 'Argument',     accent: COLORS.mutedMid, italic: false },
  EVIDENCE:    { label: 'Evidence',     accent: COLORS.amber,    italic: false },
  DIAGRAM:     { label: 'Diagram',      accent: COLORS.brown,    italic: false },
  TENSION:     { label: 'Tension',      accent: COLORS.risk,     italic: true  },
  SIGNAL:      { label: 'Signal',       accent: COLORS.teal,     italic: true  },
  FIELD_NOTE:  { label: 'Field Note',   accent: COLORS.brownLight, italic: true },
  IMPLICATION: { label: 'Implication',  accent: COLORS.amber,    italic: false },
  CITATION:    { label: 'Citation',     accent: COLORS.muted,    italic: false },
}

// ── Section renderer ──────────────────────────────────────────────────────

function SectionBlock({
  section,
  visible,
}: {
  section: PaperSection
  visible: boolean
}) {
  const cfg = SECTION_CONFIG[section.type]

  if (section.type === 'SIGNAL') {
    return (
      <div
        id={section.anchorId}
        style={{
          margin: '32px 0',
          borderLeft: `3px solid ${cfg.accent}`,
          paddingLeft: 28,
          opacity: visible ? 1 : 0,
          transform: visible ? 'translateY(0)' : 'translateY(12px)',
          transition: 'opacity 0.5s ease, transform 0.5s ease',
        }}
      >
        <MonoLabel color={cfg.accent} size={8} style={{ display: 'block', marginBottom: 10 }}>
          {cfg.label}
        </MonoLabel>
        <blockquote
          style={{
            fontFamily: FONTS.body,
            fontStyle: 'italic',
            fontSize: 20,
            color: COLORS.cream,
            lineHeight: 1.55,
            margin: 0,
          }}
        >
          "{section.content}"
        </blockquote>
        <button
          onClick={() => navigator.clipboard.writeText(section.content)}
          style={{
            marginTop: 12,
            fontFamily: FONTS.mono,
            fontSize: 8,
            letterSpacing: '0.1em',
            color: COLORS.muted,
            background: 'none',
            border: `1px solid ${COLORS.border}`,
            padding: '4px 10px',
            cursor: 'pointer',
            textTransform: 'uppercase',
            transition: TRANSITIONS.fast,
          }}
          onMouseEnter={e => { e.currentTarget.style.color = COLORS.teal; e.currentTarget.style.borderColor = COLORS.teal }}
          onMouseLeave={e => { e.currentTarget.style.color = COLORS.muted; e.currentTarget.style.borderColor = COLORS.border }}
        >
          Copy Signal →
        </button>
      </div>
    )
  }

  if (section.type === 'THESIS') {
    return (
      <div
        id={section.anchorId}
        style={{
          margin: '40px 0',
          background: COLORS.tealBg,
          border: `1px solid ${COLORS.teal}30`,
          borderLeft: `4px solid ${COLORS.teal}`,
          padding: '28px 32px',
          opacity: visible ? 1 : 0,
          transform: visible ? 'translateY(0)' : 'translateY(12px)',
          transition: 'opacity 0.5s ease, transform 0.5s ease',
        }}
      >
        <MonoLabel color={COLORS.teal} size={8} style={{ display: 'block', marginBottom: 12 }}>
          {cfg.label}
        </MonoLabel>
        <p
          style={{
            fontFamily: FONTS.serif,
            fontSize: 18,
            fontWeight: 700,
            color: COLORS.cream,
            lineHeight: 1.5,
            margin: 0,
          }}
        >
          {section.content}
        </p>
      </div>
    )
  }

  if (section.type === 'TENSION') {
    return (
      <div
        id={section.anchorId}
        style={{
          margin: '32px 0',
          background: 'rgba(184,78,58,0.06)',
          border: `1px solid ${COLORS.risk}30`,
          borderLeft: `3px solid ${COLORS.risk}`,
          padding: '20px 24px',
          opacity: visible ? 1 : 0,
          transform: visible ? 'translateY(0)' : 'translateY(12px)',
          transition: 'opacity 0.5s ease, transform 0.5s ease',
        }}
      >
        <MonoLabel color={COLORS.risk} size={8} style={{ display: 'block', marginBottom: 10 }}>
          {cfg.label}
        </MonoLabel>
        <p
          style={{
            fontFamily: FONTS.body,
            fontStyle: 'italic',
            fontSize: 15,
            color: COLORS.light,
            lineHeight: 1.72,
            margin: 0,
          }}
        >
          {section.content}
        </p>
      </div>
    )
  }

  if (section.type === 'DIAGRAM') {
    return (
      <div
        id={section.anchorId}
        style={{
          margin: '32px 0',
          border: `1px dashed ${COLORS.borderMid}`,
          padding: '28px',
          opacity: visible ? 1 : 0,
          transform: visible ? 'translateY(0)' : 'translateY(12px)',
          transition: 'opacity 0.5s ease, transform 0.5s ease',
        }}
      >
        <MonoLabel color={cfg.accent} size={8} style={{ display: 'block', marginBottom: 16 }}>
          {cfg.label}
          {section.diagramRef && ` · ${section.diagramRef}`}
        </MonoLabel>
        {/* TODO: render interactive diagram component based on section.diagramRef */}
        <div
          style={{
            background: COLORS.bgSurf,
            padding: '32px',
            textAlign: 'center',
            minHeight: 120,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <div>
            <div style={{ fontFamily: FONTS.mono, fontSize: 9, color: COLORS.muted, letterSpacing: '0.12em', marginBottom: 8 }}>
              DIAGRAM PLACEHOLDER
            </div>
            <p style={{ fontFamily: FONTS.body, fontStyle: 'italic', fontSize: 14, color: COLORS.muted, maxWidth: 400 }}>
              {section.content}
            </p>
          </div>
        </div>
      </div>
    )
  }

  if (section.type === 'CITATION') {
    return (
      <div
        id={section.anchorId}
        style={{
          margin: '16px 0',
          paddingLeft: 20,
          borderLeft: `1px solid ${COLORS.border}`,
          opacity: visible ? 1 : 0,
          transition: 'opacity 0.5s ease',
        }}
      >
        <p
          style={{
            fontFamily: FONTS.mono,
            fontSize: 11,
            color: COLORS.muted,
            lineHeight: 1.6,
            margin: 0,
          }}
        >
          {section.content}
        </p>
      </div>
    )
  }

  // Default: ARGUMENT, EVIDENCE, FIELD_NOTE, IMPLICATION
  return (
    <div
      id={section.anchorId}
      style={{
        margin: '28px 0',
        opacity: visible ? 1 : 0,
        transform: visible ? 'translateY(0)' : 'translateY(8px)',
        transition: 'opacity 0.45s ease, transform 0.45s ease',
      }}
    >
      <MonoLabel
        color={cfg.accent}
        size={8}
        style={{ display: 'block', marginBottom: 10 }}
      >
        {cfg.label}
      </MonoLabel>
      <p
        style={{
          fontFamily: FONTS.body,
          fontStyle: cfg.italic ? 'italic' : 'normal',
          fontSize: 16,
          color: COLORS.light,
          lineHeight: 1.78,
          margin: 0,
        }}
      >
        {section.content}
      </p>
    </div>
  )
}

// ── Nav Rail ──────────────────────────────────────────────────────────────

function NavRail({
  sections,
  activeAnchor,
  readingDepth,
}: {
  sections: PaperSection[]
  activeAnchor: string
  readingDepth: number
}) {
  return (
    <div
      style={{
        position: 'sticky',
        top: 60,
        width: 160,
        flexShrink: 0,
        paddingTop: 32,
        alignSelf: 'flex-start',
      }}
    >
      {/* Reading depth bar */}
      <div style={{ marginBottom: 24 }}>
        <MonoLabel size={7} style={{ display: 'block', marginBottom: 6 }}>
          Reading Depth
        </MonoLabel>
        <div style={{ height: 3, background: COLORS.bgSurf, position: 'relative' }}>
          <div
            style={{
              height: '100%',
              width: `${readingDepth}%`,
              background: COLORS.teal,
              transition: 'width 0.3s ease',
            }}
          />
        </div>
      </div>

      {/* Section nav */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
        {sections.map(s => {
          const cfg = SECTION_CONFIG[s.type]
          const active = activeAnchor === s.anchorId
          return (
            <a
              key={s.id}
              href={`#${s.anchorId}`}
              style={{
                display: 'block',
                padding: '6px 10px',
                fontFamily: FONTS.mono,
                fontSize: 8,
                letterSpacing: '0.09em',
                color: active ? cfg.accent : COLORS.muted,
                borderLeft: `2px solid ${active ? cfg.accent : 'transparent'}`,
                textDecoration: 'none',
                transition: TRANSITIONS.fast,
                textTransform: 'uppercase',
              }}
            >
              {cfg.label}
            </a>
          )
        })}
      </div>
    </div>
  )
}

// ── Signal Strip ──────────────────────────────────────────────────────────

function SignalStrip({ signals }: { signals: Signal[] }) {
  if (signals.length === 0) return null
  return (
    <div
      style={{
        borderTop: `1px solid ${COLORS.border}`,
        padding: '40px 0 0',
        marginTop: 40,
      }}
    >
      <MonoLabel color={COLORS.teal} size={8} style={{ display: 'block', marginBottom: 20 }}>
        {signals.length} Signal{signals.length !== 1 ? 's' : ''} Extracted
      </MonoLabel>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        {signals.map(sig => (
          <div
            key={sig.id}
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'flex-start',
              padding: '14px 16px',
              background: COLORS.bgSurf,
              border: `1px solid ${COLORS.border}`,
            }}
          >
            <div style={{ flex: 1, marginRight: 16 }}>
              <p
                style={{
                  fontFamily: FONTS.body,
                  fontStyle: 'italic',
                  fontSize: 15,
                  color: COLORS.cream,
                  lineHeight: 1.55,
                  margin: '0 0 8px',
                }}
              >
                "{sig.content}"
              </p>
              <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                <MonoLabel size={7} color={COLORS.teal}>
                  Weight: {sig.weight}
                </MonoLabel>
                {sig.tags.slice(0, 3).map(t => <Tag key={t} label={t} />)}
              </div>
            </div>
            <button
              onClick={() => navigator.clipboard.writeText(sig.content)}
              style={{
                fontFamily: FONTS.mono,
                fontSize: 8,
                letterSpacing: '0.1em',
                color: COLORS.muted,
                background: 'none',
                border: `1px solid ${COLORS.border}`,
                padding: '4px 10px',
                cursor: 'pointer',
                textTransform: 'uppercase',
                flexShrink: 0,
                transition: TRANSITIONS.fast,
              }}
              onMouseEnter={e => { e.currentTarget.style.color = COLORS.teal; e.currentTarget.style.borderColor = COLORS.teal }}
              onMouseLeave={e => { e.currentTarget.style.color = COLORS.muted; e.currentTarget.style.borderColor = COLORS.border }}
            >
              Copy →
            </button>
          </div>
        ))}
      </div>
    </div>
  )
}

// ── Main PaperView ────────────────────────────────────────────────────────

export function PaperView() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const [paper, setPaper] = useState<Paper | null>(null)
  const [allPapers, setAllPapers] = useState<Paper[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [visibleSections, setVisibleSections] = useState<Set<string>>(new Set())
  const [activeAnchor, setActiveAnchor] = useState('')
  const [readingDepth, setReadingDepth] = useState(0)
  const observerRef = useRef<IntersectionObserver | null>(null)
  const scrollObserverRef = useRef<IntersectionObserver | null>(null)

  // Load paper
  useEffect(() => {
    if (!id) return
    setLoading(true)
    Promise.all([getPaper(id), listPapers()])
      .then(([p, { papers }]) => {
        setPaper(p)
        setAllPapers(papers)
      })
      .catch(err => setError(err instanceof Error ? err.message : 'Failed to load'))
      .finally(() => setLoading(false))
  }, [id])

  // Scroll-triggered section reveals
  useEffect(() => {
    if (!paper) return
    observerRef.current = new IntersectionObserver(
      entries => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            setVisibleSections(prev => new Set([...prev, entry.target.id]))
          }
        })
      },
      { threshold: 0.15 }
    )
    const sectionEls = document.querySelectorAll('[data-section]')
    sectionEls.forEach(el => observerRef.current?.observe(el))
    return () => observerRef.current?.disconnect()
  }, [paper])

  // Reading depth + active anchor tracking
  useEffect(() => {
    const onScroll = () => {
      const el = document.documentElement
      const scrolled = el.scrollTop / (el.scrollHeight - el.clientHeight)
      setReadingDepth(Math.round(scrolled * 100))
    }
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  // Active anchor from scroll position
  useEffect(() => {
    if (!paper) return
    scrollObserverRef.current = new IntersectionObserver(
      entries => {
        entries.forEach(entry => {
          if (entry.isIntersecting) setActiveAnchor(entry.target.id)
        })
      },
      { rootMargin: '-30% 0px -60% 0px' }
    )
    const anchorEls = document.querySelectorAll('[id]')
    anchorEls.forEach(el => scrollObserverRef.current?.observe(el))
    return () => scrollObserverRef.current?.disconnect()
  }, [paper])

  const archivist = useArchivist({ papers: allPapers, activeCluster: paper?.cluster ?? 'ALL' })

  // Keep hovered paper = current paper while in paper view
  useEffect(() => {
    if (paper) archivist.setHoveredPaper(paper)
  }, [paper]) // eslint-disable-line react-hooks/exhaustive-deps

  if (loading) {
    return (
      <div style={{ background: COLORS.bg, minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ display: 'flex', gap: 8 }}>
          {[0, 1, 2].map(i => (
            <div key={i} style={{ width: 6, height: 6, borderRadius: '50%', background: COLORS.teal, animation: `pulse 0.8s ease-in-out infinite ${i * 0.15}s` }} />
          ))}
        </div>
      </div>
    )
  }

  if (error || !paper) {
    return (
      <div style={{ background: COLORS.bg, minHeight: '100vh', padding: '80px 40px' }}>
        <MonoLabel color={COLORS.risk} size={9} style={{ display: 'block', marginBottom: 12 }}>Error</MonoLabel>
        <p style={{ fontFamily: FONTS.body, color: COLORS.muted, fontSize: 16 }}>{error ?? 'Paper not found.'}</p>
        <button onClick={() => navigate('/')} style={{ marginTop: 20, fontFamily: FONTS.mono, fontSize: 9, letterSpacing: '0.12em', border: `1px solid ${COLORS.border}`, color: COLORS.muted, background: 'none', padding: '8px 16px', cursor: 'pointer', textTransform: 'uppercase' }}>
          ← Back to Archive
        </button>
      </div>
    )
  }

  const accent = paper.accentColor ?? COLORS.teal

  return (
    <div style={{ background: COLORS.bg, minHeight: '100vh', paddingBottom: 120 }}>

      {/* ── Top bar ─────────────────────────────────────────────────── */}
      <div style={{ background: COLORS.bgMid, borderBottom: `1px solid ${COLORS.border}`, padding: '12px 40px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', position: 'sticky', top: 0, zIndex: 50 }}>
        <div style={{ display: 'flex', gap: 20, alignItems: 'center' }}>
          <button
            onClick={() => navigate('/')}
            style={{ fontFamily: FONTS.mono, fontSize: 8, letterSpacing: '0.12em', color: COLORS.muted, background: 'none', border: 'none', cursor: 'pointer', textTransform: 'uppercase' }}
            onMouseEnter={e => e.currentTarget.style.color = COLORS.teal}
            onMouseLeave={e => e.currentTarget.style.color = COLORS.muted}
          >
            ← Archive
          </button>
          <div style={{ width: 1, height: 20, background: COLORS.border }} />
          <MonoLabel color={accent} size={8}>Paper {paper.issue}</MonoLabel>
          <MonoLabel size={8}>{paper.cluster.replace('_', ' ')}</MonoLabel>
        </div>
        <div style={{ display: 'flex', gap: 16, alignItems: 'center' }}>
          <MonoLabel size={8}>{paper.readTime} · {paper.depth.replace('_', ' ')} · {paper.date}</MonoLabel>
        </div>
      </div>

      {/* ── Page layout ─────────────────────────────────────────────── */}
      <div style={{ display: 'flex', maxWidth: 1100, margin: '0 auto', padding: '0 40px', gap: 48 }}>

        {/* Left nav rail */}
        {paper.sections.length > 0 && (
          <NavRail
            sections={paper.sections}
            activeAnchor={activeAnchor}
            readingDepth={readingDepth}
          />
        )}

        {/* Main content */}
        <div style={{ flex: 1, minWidth: 0, paddingTop: 56 }}>

          {/* Paper header */}
          <header style={{ marginBottom: 48 }}>
            <div style={{ display: 'flex', gap: 12, alignItems: 'center', marginBottom: 16 }}>
              <MonoLabel color={accent} size={9}>Paper {paper.issue}</MonoLabel>
              {paper.tags.slice(0, 4).map(t => <Tag key={t} label={t} />)}
            </div>
            <h1
              style={{
                fontFamily: FONTS.serif,
                fontSize: 40,
                fontWeight: 900,
                color: COLORS.cream,
                lineHeight: 1.1,
                letterSpacing: '-0.4px',
                marginBottom: 16,
              }}
            >
              {paper.title}
            </h1>
            <p
              style={{
                fontFamily: FONTS.serif,
                fontStyle: 'italic',
                fontSize: 18,
                color: COLORS.mutedMid,
                lineHeight: 1.45,
                marginBottom: 28,
              }}
            >
              {paper.subtitle}
            </p>
            <Divider />
            <p
              style={{
                fontFamily: FONTS.body,
                fontSize: 16,
                color: COLORS.muted,
                lineHeight: 1.78,
                marginTop: 24,
              }}
            >
              {paper.abstract}
            </p>
          </header>

          {/* Sections */}
          {paper.sections.length > 0 ? (
            paper.sections.map(section => (
              <div key={section.id} id={section.anchorId} data-section>
                <SectionBlock
                  section={section}
                  visible={visibleSections.has(section.anchorId)}
                />
              </div>
            ))
          ) : (
            <div style={{ padding: '40px 0' }}>
              <MonoLabel size={8} style={{ display: 'block', marginBottom: 12 }}>
                Full Paper
              </MonoLabel>
              <p style={{ fontFamily: FONTS.body, fontStyle: 'italic', fontSize: 15, color: COLORS.muted, lineHeight: 1.7 }}>
                Section-level content not yet available for this paper. Use the Ingest pipeline to add typed sections.
              </p>
            </div>
          )}

          {/* Signal strip */}
          <SignalStrip signals={paper.signals} />

          {/* Tensions */}
          {paper.tensions.length > 0 && (
            <div style={{ borderTop: `1px solid ${COLORS.border}`, paddingTop: 40, marginTop: 40 }}>
              <MonoLabel color={COLORS.risk} size={8} style={{ display: 'block', marginBottom: 20 }}>
                {paper.tensions.length} Cross-Paper Tension{paper.tensions.length !== 1 ? 's' : ''}
              </MonoLabel>
              {paper.tensions.map(t => (
                <div key={t.id} style={{ padding: '14px 16px', background: 'rgba(184,78,58,0.05)', border: `1px solid ${COLORS.risk}20`, borderLeft: `3px solid ${COLORS.risk}40`, marginBottom: 10 }}>
                  <MonoLabel color={COLORS.risk} size={8} style={{ display: 'block', marginBottom: 6 }}>
                    {t.relationType.replace('_', ' ')} · {t.fromPaperId} ↔ {t.toPaperId}
                  </MonoLabel>
                  <p style={{ fontFamily: FONTS.body, fontStyle: 'italic', fontSize: 14, color: COLORS.mutedMid, lineHeight: 1.65, margin: 0 }}>
                    {t.description}
                  </p>
                </div>
              ))}
            </div>
          )}

          {/* Citations */}
          {paper.citations.length > 0 && (
            <div style={{ borderTop: `1px solid ${COLORS.border}`, paddingTop: 32, marginTop: 32 }}>
              <MonoLabel size={8} style={{ display: 'block', marginBottom: 16 }}>
                Citations ({paper.citations.length})
              </MonoLabel>
              {paper.citations.map(c => (
                <p key={c.id} style={{ fontFamily: FONTS.mono, fontSize: 11, color: COLORS.muted, lineHeight: 1.65, marginBottom: 8 }}>
                  {c.text}{c.source && ` — ${c.source}`}{c.year && `, ${c.year}`}
                  {c.doi && <a href={`https://doi.org/${c.doi}`} target="_blank" rel="noreferrer" style={{ color: COLORS.teal, marginLeft: 8 }}>DOI ↗</a>}
                </p>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Ghost Archivist */}
      <GhostArchivist
        open={archivist.open}
        loading={archivist.loading}
        messages={archivist.messages}
        hoveredPaper={paper}
        papers={allPapers}
        onToggle={() => void archivist.toggle()}
        onSend={msg => archivist.sendMessage(msg)}
      />
    </div>
  )
}
