// ── SignalGraphView — D3 Force-Directed Signal Graph ─────────────────────
// Cross-paper knowledge graph. Nodes = signals. Edges = tensions/relations.
// Cluster coloring, hover detail panel, filter by cluster/relation type.

import { useEffect, useRef, useState, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import { COLORS, FONTS, TRANSITIONS } from '@/tokens'
import { MonoLabel, Tag } from '@/components/ui/primitives'
import { listPapers } from '@/lib/api'
import { Paper, Signal, Tension, RelationType, ClusterType } from '@/types'

// ── D3 types (minimal — avoids full d3 import for tree shaking) ───────────
interface D3Node extends Signal {
  x?: number
  y?: number
  fx?: number | null
  fy?: number | null
  vx?: number
  vy?: number
  paperTitle?: string
  paperAccent?: string
}

interface D3Link {
  source: string | D3Node
  target: string | D3Node
  relationType: RelationType
  tension: Tension
}

const CLUSTER_COLORS: Record<ClusterType | string, string> = {
  AI_SYSTEMS:                COLORS.teal,
  PROFESSIONAL_IDENTITY:     COLORS.brown,
  GOVERNANCE:                COLORS.mutedMid,
  HUMAN_AI_COLLABORATION:    COLORS.amber,
  ENTERPRISE_TRANSFORMATION: COLORS.brownLight,
}

const RELATION_COLORS: Record<RelationType, string> = {
  SUPPORTS:       COLORS.teal,
  EXTENDS:        COLORS.amber,
  TENSIONS_WITH:  COLORS.risk,
  CONTRADICTS:    '#E05050',
}

// ── Node detail panel ─────────────────────────────────────────────────────

function NodeDetail({
  node,
  onClose,
  onNavigate,
}: {
  node: D3Node
  onClose: () => void
  onNavigate: (paperId: string) => void
}) {
  const accent = CLUSTER_COLORS[node.cluster] ?? COLORS.teal
  return (
    <div
      style={{
        position: 'absolute',
        top: 20,
        right: 20,
        width: 280,
        background: COLORS.bgMid,
        border: `1px solid ${accent}50`,
        borderLeft: `3px solid ${accent}`,
        padding: 20,
        animation: 'fadeInUp 0.2s ease',
        zIndex: 10,
      }}
    >
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12 }}>
        <MonoLabel color={accent} size={8}>{node.cluster.replace('_', ' ')}</MonoLabel>
        <button onClick={onClose} style={{ background: 'none', border: 'none', color: COLORS.muted, cursor: 'pointer', fontFamily: FONTS.mono, fontSize: 9 }}>×</button>
      </div>
      <p style={{ fontFamily: FONTS.body, fontStyle: 'italic', fontSize: 15, color: COLORS.cream, lineHeight: 1.58, margin: '0 0 12px' }}>
        "{node.content}"
      </p>
      <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 12 }}>
        {node.tags.map(t => <Tag key={t} label={t} />)}
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <MonoLabel size={7}>Weight: {node.weight} · From: {node.paperTitle?.substring(0, 22)}…</MonoLabel>
        <button
          onClick={() => onNavigate(node.paperId)}
          style={{ fontFamily: FONTS.mono, fontSize: 7, letterSpacing: '0.1em', border: `1px solid ${accent}`, color: accent, background: 'none', padding: '4px 8px', cursor: 'pointer', textTransform: 'uppercase' }}
        >
          Open →
        </button>
      </div>
    </div>
  )
}

// ── Legend ────────────────────────────────────────────────────────────────

function GraphLegend() {
  const relations: RelationType[] = ['SUPPORTS', 'EXTENDS', 'TENSIONS_WITH', 'CONTRADICTS']
  return (
    <div
      style={{
        position: 'absolute',
        bottom: 60,
        left: 20,
        background: COLORS.bgMid,
        border: `1px solid ${COLORS.border}`,
        padding: '14px 16px',
      }}
    >
      <MonoLabel size={7} style={{ display: 'block', marginBottom: 10 }}>Edge Types</MonoLabel>
      {relations.map(r => (
        <div key={r} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
          <div style={{ width: 24, height: 2, background: RELATION_COLORS[r] }} />
          <MonoLabel size={7} color={RELATION_COLORS[r]}>{r.replace('_', ' ')}</MonoLabel>
        </div>
      ))}
      <div style={{ borderTop: `1px solid ${COLORS.border}`, paddingTop: 10, marginTop: 4 }}>
        <MonoLabel size={7} style={{ display: 'block', marginBottom: 8 }}>Clusters</MonoLabel>
        {Object.entries(CLUSTER_COLORS).map(([c, color]) => (
          <div key={c} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <div style={{ width: 8, height: 8, borderRadius: '50%', background: color }} />
            <MonoLabel size={6} color={color}>{c.replace('_', ' ')}</MonoLabel>
          </div>
        ))}
      </div>
    </div>
  )
}

// ── Canvas renderer (pure JS — no D3 import required at build time) ────────

function drawGraph(
  canvas: HTMLCanvasElement,
  nodes: D3Node[],
  links: D3Link[],
  selectedId: string | null,
  hoveredId: string | null,
  dpr: number,
) {
  const ctx = canvas.getContext('2d')
  if (!ctx) return

  ctx.clearRect(0, 0, canvas.width, canvas.height)

  // Draw links
  links.forEach(link => {
    const src = typeof link.source === 'string' ? nodes.find(n => n.id === link.source) : link.source as D3Node
    const tgt = typeof link.target === 'string' ? nodes.find(n => n.id === link.target) : link.target as D3Node
    if (!src?.x || !src?.y || !tgt?.x || !tgt?.y) return

    const color = RELATION_COLORS[link.relationType]
    ctx.beginPath()
    ctx.moveTo(src.x * dpr, src.y * dpr)
    ctx.lineTo(tgt.x * dpr, tgt.y * dpr)
    ctx.strokeStyle = color + '60'
    ctx.lineWidth = link.relationType === 'TENSIONS_WITH' || link.relationType === 'CONTRADICTS' ? 2 * dpr : 1 * dpr
    if (link.relationType === 'TENSIONS_WITH') {
      ctx.setLineDash([4 * dpr, 4 * dpr])
    } else {
      ctx.setLineDash([])
    }
    ctx.stroke()
    ctx.setLineDash([])
  })

  // Draw nodes
  nodes.forEach(node => {
    if (!node.x || !node.y) return
    const accent = CLUSTER_COLORS[node.cluster] ?? COLORS.teal
    const isSelected = node.id === selectedId
    const isHovered = node.id === hoveredId
    const r = (4 + node.weight * 2) * dpr

    // Glow for selected
    if (isSelected || isHovered) {
      ctx.beginPath()
      ctx.arc(node.x * dpr, node.y * dpr, r * 2.2, 0, Math.PI * 2)
      ctx.fillStyle = accent + '18'
      ctx.fill()
    }

    // Node circle
    ctx.beginPath()
    ctx.arc(node.x * dpr, node.y * dpr, r, 0, Math.PI * 2)
    ctx.fillStyle = isSelected ? accent : accent + 'AA'
    ctx.fill()

    // Border
    ctx.beginPath()
    ctx.arc(node.x * dpr, node.y * dpr, r, 0, Math.PI * 2)
    ctx.strokeStyle = accent
    ctx.lineWidth = 1 * dpr
    ctx.stroke()

    // Label on hover/select
    if (isSelected || isHovered) {
      const label = node.content.substring(0, 42) + (node.content.length > 42 ? '...' : '')
      ctx.font = `${9 * dpr}px 'IBM Plex Mono', monospace`
      ctx.fillStyle = COLORS.cream
      ctx.fillText(label, (node.x + r / dpr + 6) * dpr, node.y * dpr + 3 * dpr)
    }
  })
}

// ── Force simulation (no D3 required) ─────────────────────────────────────

function runForce(
  nodes: D3Node[],
  links: D3Link[],
  width: number,
  height: number,
  onTick: (nodes: D3Node[]) => void,
) {
  const cx = width / 2
  const cy = height / 2

  // Init positions
  nodes.forEach((n, i) => {
    if (!n.x) n.x = cx + Math.cos((i / nodes.length) * Math.PI * 2) * 150
    if (!n.y) n.y = cy + Math.sin((i / nodes.length) * Math.PI * 2) * 150
    n.vx = 0
    n.vy = 0
  })

  let frame = 0
  const MAX_FRAMES = 280

  function tick() {
    if (frame++ > MAX_FRAMES) return

    // Repulsion
    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        const a = nodes[i], b = nodes[j]
        const dx = (b.x ?? cx) - (a.x ?? cx)
        const dy = (b.y ?? cy) - (a.y ?? cy)
        const dist = Math.sqrt(dx * dx + dy * dy) || 1
        const force = 2400 / (dist * dist)
        const fx = (dx / dist) * force
        const fy = (dy / dist) * force
        a.vx = (a.vx ?? 0) - fx
        a.vy = (a.vy ?? 0) - fy
        b.vx = (b.vx ?? 0) + fx
        b.vy = (b.vy ?? 0) + fy
      }
    }

    // Link attraction
    links.forEach(link => {
      const src = typeof link.source === 'string' ? nodes.find(n => n.id === link.source) : link.source as D3Node
      const tgt = typeof link.target === 'string' ? nodes.find(n => n.id === link.target) : link.target as D3Node
      if (!src || !tgt) return
      const dx = (tgt.x ?? cx) - (src.x ?? cx)
      const dy = (tgt.y ?? cy) - (src.y ?? cy)
      const dist = Math.sqrt(dx * dx + dy * dy) || 1
      const target = 90
      const force = (dist - target) * 0.04
      const fx = (dx / dist) * force
      const fy = (dy / dist) * force
      src.vx = (src.vx ?? 0) + fx
      src.vy = (src.vy ?? 0) + fy
      tgt.vx = (tgt.vx ?? 0) - fx
      tgt.vy = (tgt.vy ?? 0) - fy
    })

    // Gravity toward center
    nodes.forEach(n => {
      if (n.fx !== undefined && n.fx !== null) { n.x = n.fx; n.y = n.fy ?? n.y; return }
      n.vx = (n.vx ?? 0) * 0.78 + (cx - (n.x ?? cx)) * 0.002
      n.vy = (n.vy ?? 0) * 0.78 + (cy - (n.y ?? cy)) * 0.002
      n.x = (n.x ?? cx) + (n.vx ?? 0)
      n.y = (n.y ?? cy) + (n.vy ?? 0)
    })

    onTick([...nodes])
    requestAnimationFrame(tick)
  }

  requestAnimationFrame(tick)
}

// ── Main component ─────────────────────────────────────────────────────────

export function SignalGraphView() {
  const navigate = useNavigate()
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [papers, setPapers] = useState<Paper[]>([])
  const [nodes, setNodes] = useState<D3Node[]>([])
  const [links, setLinks] = useState<D3Link[]>([])
  const [selectedNode, setSelectedNode] = useState<D3Node | null>(null)
  const [hoveredId, setHoveredId] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const [filterCluster, setFilterCluster] = useState<ClusterType | 'ALL'>('ALL')
  const nodesRef = useRef<D3Node[]>([])
  const dpr = window.devicePixelRatio || 1

  // Load data
  useEffect(() => {
    listPapers().then(({ papers: p }) => {
      setPapers(p)

      const allNodes: D3Node[] = p.flatMap(paper =>
        paper.signals.map(sig => ({
          ...sig,
          paperTitle: paper.title,
          paperAccent: paper.accentColor,
        }))
      )

      const allLinks: D3Link[] = p.flatMap(paper =>
        paper.tensions.map(t => ({
          source: t.fromSignalId,
          target: t.toSignalId,
          relationType: t.relationType,
          tension: t,
        }))
      )

      setNodes(allNodes)
      setLinks(allLinks)
      nodesRef.current = allNodes
      setLoading(false)
    }).catch(() => setLoading(false))
  }, [])

  // Run simulation
  useEffect(() => {
    if (nodes.length === 0) return
    const canvas = canvasRef.current
    if (!canvas) return
    const w = canvas.clientWidth
    const h = canvas.clientHeight
    runForce(nodes, links, w, h, updated => {
      nodesRef.current = updated
      if (canvas) drawGraph(canvas, updated, links, selectedNode?.id ?? null, hoveredId, dpr)
    })
  }, [nodes.length]) // eslint-disable-line react-hooks/exhaustive-deps

  // Redraw on selection/hover change
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    drawGraph(canvas, nodesRef.current, links, selectedNode?.id ?? null, hoveredId, dpr)
  }, [selectedNode, hoveredId, links, dpr])

  // Canvas sizing
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const resize = () => {
      canvas.width = canvas.clientWidth * dpr
      canvas.height = canvas.clientHeight * dpr
      drawGraph(canvas, nodesRef.current, links, selectedNode?.id ?? null, hoveredId, dpr)
    }
    resize()
    window.addEventListener('resize', resize)
    return () => window.removeEventListener('resize', resize)
  }, [links, selectedNode, hoveredId, dpr])

  const getNodeAt = useCallback((x: number, y: number): D3Node | null => {
    for (const node of nodesRef.current) {
      if (!node.x || !node.y) continue
      const r = 4 + node.weight * 2
      const dx = node.x - x
      const dy = node.y - y
      if (Math.sqrt(dx * dx + dy * dy) < r + 6) return node
    }
    return null
  }, [])

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const rect = e.currentTarget.getBoundingClientRect()
    const node = getNodeAt(e.clientX - rect.left, e.clientY - rect.top)
    setHoveredId(node?.id ?? null)
    e.currentTarget.style.cursor = node ? 'pointer' : 'grab'
  }

  const handleClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const rect = e.currentTarget.getBoundingClientRect()
    const node = getNodeAt(e.clientX - rect.left, e.clientY - rect.top)
    setSelectedNode(node ?? null)
  }

  const filteredTotal = filterCluster === 'ALL'
    ? nodes.length
    : nodes.filter(n => n.cluster === filterCluster).length

  const clusters = Array.from(new Set(nodes.map(n => n.cluster)))

  return (
    <div style={{ background: COLORS.bg, height: '100vh', display: 'flex', flexDirection: 'column' }}>

      {/* Top bar */}
      <div style={{ background: COLORS.bgMid, borderBottom: `1px solid ${COLORS.border}`, padding: '12px 40px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexShrink: 0 }}>
        <div style={{ display: 'flex', gap: 20, alignItems: 'center' }}>
          <button onClick={() => navigate('/')} style={{ fontFamily: FONTS.mono, fontSize: 8, letterSpacing: '0.12em', color: COLORS.muted, background: 'none', border: 'none', cursor: 'pointer', textTransform: 'uppercase' }}>
            ← Archive
          </button>
          <div style={{ width: 1, height: 20, background: COLORS.border }} />
          <MonoLabel color={COLORS.teal} size={9}>Signal Graph</MonoLabel>
          <MonoLabel size={8}>{filteredTotal} Signals · {links.length} Relations</MonoLabel>
        </div>

        {/* Cluster filter chips */}
        <div style={{ display: 'flex', gap: 6 }}>
          {(['ALL', ...clusters] as const).map(c => (
            <button
              key={c}
              onClick={() => setFilterCluster(c as ClusterType | 'ALL')}
              style={{
                fontFamily: FONTS.mono,
                fontSize: 7,
                letterSpacing: '0.08em',
                border: `1px solid ${filterCluster === c ? CLUSTER_COLORS[c] ?? COLORS.teal : COLORS.border}`,
                color: filterCluster === c ? CLUSTER_COLORS[c] ?? COLORS.teal : COLORS.muted,
                background: 'transparent',
                padding: '4px 10px',
                cursor: 'pointer',
                textTransform: 'uppercase',
                transition: TRANSITIONS.fast,
              }}
            >
              {c === 'ALL' ? 'All' : c.replace('_', ' ')}
            </button>
          ))}
        </div>
      </div>

      {/* Canvas area */}
      <div style={{ flex: 1, position: 'relative', overflow: 'hidden' }}>
        {loading ? (
          <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <div style={{ display: 'flex', gap: 8 }}>
              {[0, 1, 2].map(i => (
                <div key={i} style={{ width: 6, height: 6, borderRadius: '50%', background: COLORS.teal, animation: `pulse 0.8s ease-in-out infinite ${i * 0.15}s` }} />
              ))}
            </div>
          </div>
        ) : nodes.length === 0 ? (
          <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontFamily: FONTS.serif, fontSize: 20, fontStyle: 'italic', color: COLORS.muted, marginBottom: 16 }}>
                No signals or tensions to graph yet.
              </div>
              <button onClick={() => navigate('/')} style={{ fontFamily: FONTS.mono, fontSize: 9, letterSpacing: '0.12em', border: `1px solid ${COLORS.teal}`, color: COLORS.teal, background: 'none', padding: '8px 16px', cursor: 'pointer', textTransform: 'uppercase' }}>
                ← Add papers to build the graph
              </button>
            </div>
          </div>
        ) : (
          <canvas
            ref={canvasRef}
            onMouseMove={handleMouseMove}
            onClick={handleClick}
            style={{ width: '100%', height: '100%', display: 'block' }}
          />
        )}

        {/* Selected node detail */}
        {selectedNode && (
          <NodeDetail
            node={selectedNode}
            onClose={() => setSelectedNode(null)}
            onNavigate={pid => navigate(`/paper/${pid}`)}
          />
        )}

        {/* Legend */}
        {!loading && nodes.length > 0 && <GraphLegend />}

        {/* Empty state hint */}
        {!loading && nodes.length > 0 && (
          <div style={{ position: 'absolute', bottom: 16, right: 20 }}>
            <MonoLabel size={7}>Click a node for detail · Drag canvas to pan</MonoLabel>
          </div>
        )}
      </div>
    </div>
  )
}
