# Research OS
### Third Signal Labs — Interactive Research Library + Ghost Archivist

A living research library where Third Signal Labs publishes original research as interactive exhibits — not PDFs. Each paper is a typed, signal-indexed, tension-aware experience. The Ghost Archivist is the ambient intelligence layer: an always-present research curator powered by Claude that has read everything and remembers the connections the authors forgot to make.

---

## Quick Start

```bash
# 1. Clone and install
git clone https://github.com/thirdsignallabs/research-os.git
cd research-os
npm install

# 2. Configure environment
cp .env.example .env.local
# Edit .env.local — add your VITE_ANTHROPIC_API_KEY at minimum

# 3. Run
npm run dev
# Opens at http://localhost:5173
```

**The app runs in SEED MODE by default** — 4 pre-loaded papers (MNEME, Professional DNA, Ghost Hand, COE Cookie) with full signal data. No backend required to start developing.

---

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `VITE_ANTHROPIC_API_KEY` | **Yes** | Powers the Ghost Archivist. Get at [console.anthropic.com](https://console.anthropic.com) |
| `VITE_RESEARCH_OS_BASE_URL` | No | Backend API URL. Leave empty to use seed data |
| `VITE_RESEARCH_OS_API_KEY` | No | API key for backend. Required if BASE_URL is set |
| `VITE_ENABLE_INGEST` | No | Enable the ingest modal (default: `true`) |
| `VITE_ENABLE_SIGNAL_GRAPH` | No | Enable Signal Graph view (default: `false`, not yet built) |

---

## Project Structure

```
src/
├── tokens.ts                     # Design tokens — colors, fonts, spacing, animations
├── types.ts                      # All TypeScript interfaces
├── App.tsx                       # App root + router (routes commented — add as views are built)
├── main.tsx                      # Entry point
│
├── data/
│   └── seed.ts                   # Seed papers for dev/demo mode
│
├── lib/
│   ├── api.ts                    # Research OS API client (auto-falls back to seed mode)
│   └── archivist.ts              # Ghost Archivist — Claude API integration + system prompt
│
├── hooks/
│   ├── usePapers.ts              # Paper data fetching + filter state
│   └── useArchivist.ts           # Archivist state management
│
└── components/
    ├── ui/
    │   └── primitives.tsx        # MonoLabel, Tag, Divider, SkeletonCard, SeedModeBanner
    ├── library/
    │   ├── TopBar.tsx            # Sticky top navigation
    │   ├── LeftRail.tsx          # Cluster + depth filter nav
    │   ├── PaperCards.tsx        # PaperCard + FeaturedPaper
    │   └── LibraryView.tsx       # Main library page (composes everything)
    ├── archivist/
    │   └── GhostArchivist.tsx    # Ghost Archivist panel + anchor strip
    └── ingest/
        └── IngestModal.tsx       # Paper ingestion modal + pipeline animation
```

---

## Design System

All visual constants live in `src/tokens.ts`. **Never hardcode colors, fonts, or spacing in components.**

```typescript
import { COLORS, FONTS, SPACING, TRANSITIONS } from '@/tokens'

// Use:
color: COLORS.teal
fontFamily: FONTS.mono
transition: TRANSITIONS.normal
```

### Type Scale
| Token | Size | Use |
|-------|------|-----|
| `FONTS.serif` | Playfair Display | Headlines, paper titles |
| `FONTS.body` | EB Garamond | Body text, abstracts |
| `FONTS.mono` | IBM Plex Mono | Labels, metadata, UI chrome |

### Color Palette
| Token | Hex | Use |
|-------|-----|-----|
| `COLORS.teal` | `#4B9E8D` | Primary accent, active states |
| `COLORS.amber` | `#C9853A` | Depth filter, secondary accent |
| `COLORS.brown` | `#8C6A4A` | PROFESSIONAL_IDENTITY cluster |
| `COLORS.risk` | `#B84E3A` | Errors, warnings |
| `COLORS.bg` | `#0C0E0D` | Page background |
| `COLORS.cream` | `#E8E4DA` | Primary text on dark |

---

## The Ghost Archivist

The Archivist is the intelligence layer of the library. **Its character is defined in `src/lib/archivist.ts`** — this is the most important file to understand before building features around it.

### Character Rules (enforce in code review)
- Responds in 2–4 sentences maximum
- Never starts with "I" or "Certainly"
- Never lists multiple insights — one sharp observation only
- Never summarizes what papers already say explicitly
- Speaks in past tense about the library, present tense about what it implies
- Uses quotation marks when citing a signal, attributes the paper number

### How It Works
1. `useArchivist` hook manages all state
2. On first panel open → fires a proactive insight (from `PROACTIVE_PROMPTS` in archivist.ts)
3. Every message call rebuilds the system prompt dynamically with current library context + hover context
4. Conversation history (max 8 turns) is passed on each call
5. Without `VITE_ANTHROPIC_API_KEY` → graceful fallback message, app still functions

### Extending the Archivist
To change the Archivist's behavior, edit `buildSystemPrompt()` in `src/lib/archivist.ts`. The function receives the full paper index, active cluster filter, and hovered paper — add anything else you want the Archivist to know.

---

## Seed Mode vs Live Mode

| | Seed Mode | Live Mode |
|--|-----------|-----------|
| Trigger | `VITE_RESEARCH_OS_BASE_URL` not set | Base URL configured |
| Data | `src/data/seed.ts` | Research OS REST API |
| Ingest | Simulated (fake pipeline animation, no real call) | Real API call |
| Archivist | Fully functional (still calls Claude API) | Fully functional |
| Indicator | Amber banner at top of page | None |

---

## What's Built (v0.1)

- [x] Library archive view (featured paper + grid)
- [x] Cluster and depth filters
- [x] Paper cards with hover states
- [x] Ghost Archivist panel (proactive insights + conversation)
- [x] Ingest modal with pipeline animation
- [x] Seed mode with 4 full papers
- [x] API client with seed mode fallback
- [x] All TypeScript interfaces

## What's Next (backlog)

- [ ] Paper detail view — full typed section rendering (THESIS / ARGUMENT / SIGNAL / etc.)
- [ ] Signal mode — compressed executive summary view
- [ ] Map mode — concept diagram view
- [ ] Signal Graph — D3 force-directed cross-paper knowledge graph
- [ ] Paper nav rail with reading depth indicator
- [ ] Scroll-triggered section reveals
- [ ] Real Google Docs / PDF ingest pipeline (requires backend)
- [ ] Author review queue for signal approval
- [ ] Interest feed integration (from MCP server)

---

## Architecture Notes for the Dev Team

### Adding a New Paper (Seed Mode)
Add to `src/data/seed.ts`. Follow the `Paper` interface in `src/types.ts`. Include at least:
- `id`, `issue`, `title`, `subtitle`, `abstract`
- `cluster`, `depth`, `readTime`, `date`
- At least 2 `signals` with `content`, `weight`, `tags`
- `accentColor` from `COLORS` token

### Adding a New View
1. Create `src/components/[domain]/YourView.tsx`
2. Add a route in `src/App.tsx` (the router comments show where)
3. Add a `useYourData` hook in `src/hooks/` if it needs data
4. Add API method to `src/lib/api.ts` with seed mode fallback

### Working with the Archivist
Always go through `useArchivist` hook — never call `callArchivist` directly from components. The hook manages conversation history and loading state.

### Component Style Convention
All styling is inline CSS via `style` prop. No CSS-in-JS, no Tailwind, no CSS modules. This keeps visual logic traceable back to `tokens.ts`. Use the token constants — never hardcode values.

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Framework | React 18 + TypeScript |
| Build | Vite 5 |
| Routing | react-router-dom v6 |
| Charts (future) | recharts |
| Icons (future) | lucide-react |
| AI | Anthropic API (claude-sonnet-4-20250514) |
| Fonts | Google Fonts — Playfair Display, EB Garamond, IBM Plex Mono |
| State | React hooks only (no external state manager) |
| Backend | Research OS REST API (separate Cloud Run service) |

---

## Related Systems

| System | Description | Repo |
|--------|-------------|------|
| Research OS API | Backend REST API + Firestore | `research-os-api` |
| Research OS MCP Server | Orbital OS integration layer | `research-os-mcp-server` |
| Orbital OS | Agent swarm platform | `orbital-os` |

---

*Third Signal Labs · Research OS v0.1 · March 2026*
*Lenox Saint Germain Lucian — GenAI Solution Architect*
